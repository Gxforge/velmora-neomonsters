# Telegram

Bot: `@GameVelmoraBot` (verified reachable with the supplied token via `getMe`).

| Feature | Status |
|---|---|
| Mini App login via `initData` (server validation, max age 1h) | IMPLEMENTED |
| Webhook endpoint `/api/telegram/webhook` with secret header, update dedupe | IMPLEMENTED |
| `/start` replies with a Play button (needs `APP_URL`) | IMPLEMENTED, untested against live Telegram |
| `pre_checkout_query` / `successful_payment` handling | IMPLEMENTED (see PAYMENTS.md) |
| Webhook registered on Telegram | NOT DONE (needs a deployed https URL) |
| BotFather Mini App / menu button configuration | TODO (manual, needs the deployed URL) |
| Notifications, referral/deep-link start params | NOT IMPLEMENTED |

## Setup once deployed
1. Set env vars (`.env.example`) in Vercel for each environment; use a **different bot** for staging if possible.
2. `APP_URL=https://<deployment> TELEGRAM_WEBHOOK_SECRET=... TELEGRAM_BOT_TOKEN=... npm run telegram:webhook`
3. BotFather: `/newapp` or set the menu button URL to `APP_URL`.
4. Put your Telegram numeric id in `ADMIN_TELEGRAM_IDS` to get admin access.
