import { describe, expect, it } from "vitest";
import { CombatError, elementMultiplier, newBattle, resolveTurn, type BattleState } from "@/lib/game/combat";
import { SPECIES, SPECIES_BY_ID } from "@/lib/game/catalog";
import { applyXp, checkEvolution, pickEnemy, statAt, winRewards, xpToNext } from "@/lib/game/progression";

const fighter = (over = {}) => ({
  name: "T", element: "fire" as const, level: 10, maxHp: 100, atk: 20, def: 10, spd: 10, ...over,
});

function playOut(seed: string, mk: () => BattleState) {
  let s = mk();
  const log: unknown[] = [];
  while (!s.winner) {
    const r = resolveTurn(s, "attack", seed);
    s = r.state;
    log.push(r.events);
  }
  return { s, log };
}

describe("catalog", () => {
  it("has 6 lines x 3 stages with consistent evolution chains", () => {
    expect(SPECIES).toHaveLength(18);
    for (const s of SPECIES) {
      if (s.stage < 3) {
        const next = SPECIES_BY_ID.get(s.evolvesTo!)!;
        expect(next.lineId).toBe(s.lineId);
        expect(next.stage).toBe(s.stage + 1);
        expect(next.baseHp).toBeGreaterThan(s.baseHp);
      } else expect(s.evolvesTo).toBeNull();
    }
    expect(new Set(SPECIES.map((s) => s.name)).size).toBe(18);
  });
});

describe("combat engine (server authoritative)", () => {
  const mk = () => newBattle(fighter(), fighter({ element: "water" }));

  it("is deterministic for the same seed (replayable/auditable)", () => {
    expect(playOut("seed-1", mk)).toEqual(playOut("seed-1", mk));
  });

  it("always terminates with a winner and never produces 0/negative damage", () => {
    for (let i = 0; i < 50; i++) {
      const { s, log } = playOut(`s${i}`, mk);
      expect(["player", "enemy", "draw"]).toContain(s.winner);
      for (const ev of (log as { action: string; damage: number }[][]).flat()) {
        if (ev.action !== "guard") expect(ev.damage).toBeGreaterThanOrEqual(1);
      }
      expect(s.player.hp).toBeGreaterThanOrEqual(0);
    }
  });

  it("applies element multipliers", () => {
    expect(elementMultiplier("water", "fire")).toBe(1.5);
    expect(elementMultiplier("fire", "water")).toBe(0.67);
    expect(elementMultiplier("light", "dark")).toBe(1.5);
    expect(elementMultiplier("fire", "dark")).toBe(1);
  });

  it("rejects invalid actions, skill on cooldown and acting after the end", () => {
    const s0 = mk();
    expect(() => resolveTurn(s0, "damage=999999" as never, "x")).toThrow(CombatError);
    const { state } = resolveTurn(s0, "skill", "x");
    expect(() => resolveTurn(state, "skill", "x")).toThrow(/skill_on_cooldown/);
    const dead: BattleState = { ...s0, winner: "player" };
    expect(() => resolveTurn(dead, "attack", "x")).toThrow(/battle_over/);
  });

  it("faster fighter acts first and a fainted fighter does not act", () => {
    const s = newBattle(fighter({ spd: 5, atk: 1 }), fighter({ spd: 50, atk: 999, level: 100 }));
    const { events, state } = resolveTurn(s, "attack", "k");
    expect(events[0].actor).toBe("enemy");
    expect(state.winner).toBe("enemy");
    expect(events).toHaveLength(1);
  });

  it("guarding reduces damage taken (same seed, same enemy behaviour)", () => {
    const base = newBattle(fighter({ spd: 99 }), fighter({ spd: 1, element: "dark", atk: 40 }));
    let guard = 0, open = 0;
    for (let i = 0; i < 40; i++) {
      const dmg = (a: "guard" | "attack") =>
        resolveTurn(base, a, `g${i}`).events.filter((e) => e.actor === "enemy").reduce((t, e) => t + e.damage, 0);
      guard += dmg("guard");
      open += dmg("attack");
    }
    expect(guard).toBeGreaterThan(0);
    expect(guard).toBeLessThan(open * 0.6);
  });
});

describe("progression", () => {
  it("levels up and caps", () => {
    expect(applyXp(1, 0, xpToNext(1))).toEqual({ level: 2, xp: 0 });
    expect(applyXp(1, 0, 5)).toEqual({ level: 1, xp: 5 });
    expect(applyXp(100, 0, 99999).level).toBe(100);
    expect(applyXp(3, 10, -50).xp).toBe(10);
  });
  it("evolution rules", () => {
    expect(checkEvolution(1, 15)).toEqual({ ok: false, reason: "level_too_low" });
    expect(checkEvolution(1, 16)).toMatchObject({ ok: true, cost: { gold: 500 } });
    expect(checkEvolution(3, 100)).toEqual({ ok: false, reason: "max_stage" });
    expect(checkEvolution(2, 36)).toMatchObject({ ok: true, cost: { crystals: 25 } });
  });
  it("stats grow, rewards scale, enemy pick is deterministic and level-appropriate", () => {
    expect(statAt(100, 10)).toBeGreaterThan(statAt(100, 1));
    expect(winRewards(10).gold).toBeLessThan(winRewards(20).gold);
    expect(pickEnemy("a", 5)).toEqual(pickEnemy("a", 5));
    expect(pickEnemy("a", 5).species.stage).toBe(1);
    expect(pickEnemy("a", 50).species.stage).toBe(3);
  });
});
