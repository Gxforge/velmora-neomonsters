import { describe, expect, it } from "vitest";
import { InitDataError, signInitDataForTests, validateInitData } from "@/lib/telegram/initData";
import { signSession, verifySession } from "@/lib/session";

const BOT = "123456:TEST_TOKEN_FOR_UNIT_TESTS_ONLY";
const now = 1_800_000_000_000;
const fields = (over: Record<string, string> = {}) => ({
  auth_date: String(Math.floor(now / 1000) - 10),
  query_id: "AAH",
  user: JSON.stringify({ id: 4242, first_name: "Ana", username: "ana" }),
  ...over,
});

describe("Telegram initData validation", () => {
  it("accepts correctly signed data", () => {
    const r = validateInitData(signInitDataForTests(fields(), BOT), BOT, { nowMs: now });
    expect(r.user.id).toBe(4242);
  });

  it("rejects a different bot token (forged data)", () => {
    const data = signInitDataForTests(fields(), "999:OTHER");
    expect(() => validateInitData(data, BOT, { nowMs: now })).toThrowError(InitDataError);
  });

  it("rejects tampered user id", () => {
    const params = new URLSearchParams(signInitDataForTests(fields(), BOT));
    params.set("user", JSON.stringify({ id: 1, first_name: "Admin" }));
    expect(() => validateInitData(params.toString(), BOT, { nowMs: now })).toThrow(/bad_hash/);
  });

  it("rejects expired data (replay protection)", () => {
    const old = signInitDataForTests(fields({ auth_date: String(Math.floor(now / 1000) - 7200) }), BOT);
    expect(() => validateInitData(old, BOT, { nowMs: now })).toThrow(/expired/);
  });

  it("rejects missing/oversized/malformed input", () => {
    expect(() => validateInitData("", BOT)).toThrow(/missing/);
    expect(() => validateInitData("a".repeat(5000), BOT)).toThrow(/malformed/);
    expect(() => validateInitData("hash=zz", BOT)).toThrow(/malformed/);
  });

  it("rejects bot users", () => {
    const d = signInitDataForTests(fields({ user: JSON.stringify({ id: 9, is_bot: true }) }), BOT);
    expect(() => validateInitData(d, BOT, { nowMs: now })).toThrow(/no_user/);
  });
});

describe("session tokens", () => {
  const secret = "s".repeat(40);
  it("round-trips and rejects tampering/expiry/wrong secret", () => {
    const t = signSession({ pid: "p1", tg: 7 }, secret, 60, now);
    expect(verifySession(t, secret, now + 1000)?.pid).toBe("p1");
    expect(verifySession(t, secret, now + 61_000)).toBeNull();
    expect(verifySession(t, "x".repeat(40), now)).toBeNull();
    const [v, body, sig] = t.split(".");
    const forged = Buffer.from(JSON.stringify({ pid: "admin", tg: 7, exp: 9e9 })).toString("base64url");
    expect(verifySession(`${v}.${forged}.${sig}`, secret, now)).toBeNull();
    expect(verifySession("garbage", secret)).toBeNull();
    expect(body.length).toBeGreaterThan(0);
  });
  it("refuses weak secrets", () => {
    expect(() => signSession({ pid: "p", tg: 1 }, "short")).toThrow();
  });
});
