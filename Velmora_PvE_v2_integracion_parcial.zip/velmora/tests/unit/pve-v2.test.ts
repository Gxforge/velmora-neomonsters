import { describe, expect, it } from "vitest";
import { newBattle, resolveTurn, enemyIntent } from "@/lib/game/combat";
import { captureChance, REGIONS, QUESTS } from "@/lib/game/adventure";
const fighter = (element: "fire" | "water" | "earth" | "lightning" | "light" | "dark", spd = 10) =>
 ({ name: element, element, level: 5, maxHp: 500, atk: 20, def: 20, spd });
describe("pve-v2 rules", () => {
 it("guard protects the slow fighter in the current round", () => {
  const s = newBattle(fighter("fire",1),fighter("dark",99));
  const open = resolveTurn(s,"attack","same");
  const guarded = resolveTurn(s,"guard","same");
  expect(guarded.events[0].damage).toBeLessThan(open.events[0].damage);
  expect(guarded.state.player.guarding).toBe(false);
 });
 it("has visible deterministic enemy intentions", () => {
  const s = newBattle(fighter("earth"),fighter("fire"));
  expect(enemyIntent(s)).toBe("attack");
  s.turn=2;expect(enemyIntent(s)).toBe("skill");
  expect(resolveTurn(s,"attack","seed").events.find(e=>e.actor==="enemy"&&e.kind==="action")?.action).toBe("skill");
 });
 it("each element has a separate effect and cooldown", () => {
  for(const element of ["fire","water","earth","lightning","light","dark"] as const) {
   const s = newBattle(fighter(element,99),fighter("earth",1));s.player.hp=300;
   const r=resolveTurn(s,"skill","skills");
   expect(r.events.find(e=>e.actor==="player")?.effect).toBeTruthy();
   expect(r.state.player.skillCooldown).toBe(3);
   if(element==="water")expect(r.state.player.hp).toBeGreaterThan(300);
   if(element==="fire")expect(r.state.enemy.effects?.burn).toBe(2);
  }
 });
 it("keeps the first capture guaranteed, later probabilities visible", () => {
  expect(captureChance(1)).toBe(1);expect(captureChance(2)).toBe(.65);
  expect(REGIONS).toHaveLength(3);expect(QUESTS.length).toBeGreaterThan(0);
 });
 it("resolves simultaneous burn knockouts as draw", () => {
  const s=newBattle(fighter("earth"),fighter("earth"));
  for(const f of [s.player,s.enemy]){ f.hp=1;f.atk=1;f.effects={burn:2,weak:0,shield:0,haste:0}; }
  s.turn=3; // enemy also guards this round
  expect(resolveTurn(s,"guard","burn").state.winner).toBe("draw");
 });
});
