/**
 * Integration tests: real route handlers + real Postgres (local DATABASE_URL).
 * Telegram's network API is never called (only pure/DB paths are exercised).
 */
import "dotenv/config";
import { randomUUID } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { beforeAll, describe, expect, it } from "vitest";
import { signInitDataForTests } from "@/lib/telegram/initData";

const BOT = "111:INTEGRATION_TEST_BOT_TOKEN";
const WEBHOOK = "w".repeat(24);
const base = Math.floor(Math.random() * 1e9) + 1e9;
const ADMIN_TG = base + 1;
process.env.TELEGRAM_BOT_TOKEN = BOT;
process.env.SESSION_SECRET = "t".repeat(48);
process.env.TELEGRAM_WEBHOOK_SECRET = WEBHOOK;
process.env.ADMIN_TELEGRAM_IDS = String(ADMIN_TG);

type Ctx = { params: Promise<{ id: string }> };
 
type Handler = (req: Request, ctx: any) => Promise<Response>;

async function call(h: Handler, o: { token?: string; body?: unknown; id?: string; method?: string; headers?: Record<string, string>; url?: string } = {}) {
  const headers: Record<string, string> = { "content-type": "application/json", ...(o.headers ?? {}) };
  if (o.token) headers.authorization = `Bearer ${o.token}`;
  const req = new Request(o.url ?? "http://t/api", { method: o.method ?? "POST", headers, body: o.body === undefined ? undefined : JSON.stringify(o.body) });
  const res = await h(req, { params: Promise.resolve({ id: o.id ?? "" }) } satisfies Ctx);
  return { status: res.status, body: (await res.json()) as Record<string, any> };  
}

const initFor = (tg: number, authAgeSec = 5) =>
  signInitDataForTests(
    { auth_date: String(Math.floor(Date.now() / 1000) - authAgeSec), user: JSON.stringify({ id: tg, first_name: `P${tg}` }), query_id: "q" },
    BOT,
  );

let r: Awaited<ReturnType<typeof load>>;
async function load() {
  const [db, schema, auth, me, starter, battles, battleAct, evolve, webhook, adminMetrics, adminBan, adminGrant, econ, pay, rl, adminSvc] = await Promise.all([
    import("@/db"), import("@/db/schema"), import("@/app/api/auth/telegram/route"), import("@/app/api/me/route"),
    import("@/app/api/starter/route"), import("@/app/api/battles/route"), import("@/app/api/battles/[id]/action/route"),
    import("@/app/api/monsters/[id]/evolve/route"), import("@/app/api/telegram/webhook/route"),
    import("@/app/api/admin/metrics/route"), import("@/app/api/admin/players/[id]/ban/route"), import("@/app/api/admin/grant/route"),
    import("@/server/economy"), import("@/server/payments"), import("@/server/rateLimit"), import("@/server/admin"),
  ]);
  return { ...db, schema, auth, me, starter, battles, battleAct, evolve, webhook, adminMetrics, adminBan, adminGrant, econ, pay, rl, adminSvc };
}

beforeAll(async () => {
  r = await load();
});

async function newPlayer(tg: number) {
  const res = await call(r.auth.POST, { body: { initData: initFor(tg) } });
  expect(res.status).toBe(200);
  return { token: res.body.token as string, id: res.body.player.id as string, tg };
}
const profile = async (token: string) => (await call(r.me.GET, { token, method: "GET" })).body;

describe("authentication & accounts", () => {
  it("registers on first login, reuses the account afterwards, links identity separately", async () => {
    const a = await newPlayer(base + 10);
    const again = await newPlayer(base + 10);
    expect(again.id).toBe(a.id);
    const [identity] = await r.db.select().from(r.schema.telegramIdentities).where(eq(r.schema.telegramIdentities.telegramUserId, base + 10));
    expect(identity.playerId).toBe(a.id);
    expect((await profile(a.token)).needsStarter).toBe(true);
  });

  it("rejects forged, stale and missing credentials", async () => {
    const forged = signInitDataForTests({ auth_date: String(Math.floor(Date.now() / 1000)), user: JSON.stringify({ id: 5 }) }, "999:evil");
    expect((await call(r.auth.POST, { body: { initData: forged } })).status).toBe(401);
    expect((await call(r.auth.POST, { body: { initData: initFor(base + 11, 99999) } })).status).toBe(401);
    expect((await call(r.me.GET, { method: "GET" })).status).toBe(401);
    expect((await call(r.me.GET, { method: "GET", token: "v1.x.y" })).status).toBe(401);
  });
});

describe("economy ledger", () => {
  it("is idempotent, never negative, and append-only", async () => {
    const p = await newPlayer(base + 20);
    const k = `test:${randomUUID()}`;
    const run = (key: string, delta: number) =>
      r.db.transaction((tx) => r.econ.applyLedger(tx, { playerId: p.id, currency: "gold", delta, reason: "test", idempotencyKey: key }));
    expect((await run(k, 50)).applied).toBe(true);
    expect((await run(k, 50)).applied).toBe(false);
    expect((await profile(p.token)).balances.gold).toBe(50);
    await expect(run(`test:${randomUUID()}`, -51)).rejects.toMatchObject({ status: 402 });
    expect((await profile(p.token)).balances.gold).toBe(50);
    await expect(r.db.execute(sql`update ledger_entries set delta = 1000000 where idempotency_key = ${k}`)).rejects.toThrow();
    await expect(r.db.execute(sql`delete from ledger_entries where idempotency_key = ${k}`)).rejects.toThrow();
    await expect(r.db.execute(sql`update player_balances set gold = -5 where player_id = ${p.id}`)).rejects.toThrow();
  });

  it("concurrent identical requests credit exactly once", async () => {
    const p = await newPlayer(base + 21);
    const k = `race:${randomUUID()}`;
    const run = () => r.db.transaction((tx) => r.econ.applyLedger(tx, { playerId: p.id, currency: "crystals", delta: 10, reason: "t", idempotencyKey: k }));
    const results = await Promise.all([run(), run(), run(), run()]);
    expect(results.filter((x) => x.applied)).toHaveLength(1);
    expect((await profile(p.token)).balances.crystals).toBe(10);
  });
});

async function withStarter(tg: number, line = "fire") {
  const p = await newPlayer(tg);
  const res = await call(r.starter.POST, { token: p.token, body: { lineId: line } });
  expect(res.status).toBe(201);
  return { ...p, monsterId: res.body.id as string };
}

const credit = (playerId: string, currency: "gold" | "crystals", delta: number) =>
  r.db.transaction((tx) => r.econ.applyLedger(tx, { playerId, currency, delta, reason: "test", idempotencyKey: `t:${randomUUID()}` }));

describe("starter, battles, rewards", () => {
  it("starter is chosen once, validated, and grants gold through the ledger", async () => {
    const p = await newPlayer(base + 30);
    expect((await call(r.starter.POST, { token: p.token, body: { lineId: "dark" } })).status).toBe(400);
    expect((await call(r.starter.POST, { token: p.token, body: { lineId: "water" } })).status).toBe(201);
    expect((await call(r.starter.POST, { token: p.token, body: { lineId: "fire" } })).status).toBe(409);
    const pr = await profile(p.token);
    expect(pr.monsters).toHaveLength(1);
    expect(pr.balances.gold).toBe(100);
    expect(pr.needsStarter).toBe(false);
  });

  it("plays a full battle server-side; client-supplied damage/winner is ignored; reward paid once", async () => {
    const p = await withStarter(base + 40);
    const start = await call(r.battles.POST, { token: p.token, body: { monsterId: p.monsterId } });
    expect(start.status).toBe(201);
    const bid = start.body.id as string;
    // resume after "disconnect"
    const resumed = await call(r.battles.POST, { token: p.token, body: { monsterId: p.monsterId } });
    expect(resumed.body.id).toBe(bid);
    expect(resumed.body.resumed).toBe(true);

    let last = start.body;
    for (let i = 0; i < 60 && last.status === "active"; i++) {
      const res = await call(r.battleAct.POST, { token: p.token, id: bid, body: { actionId: randomUUID(), expectedTurn: last.turn, action: "attack", damage: 999999, winner: "player", critical: true } });
      expect([200]).toContain(res.status);
      last = res.body;
    }
    expect(last.status).not.toBe("active");
    const [{ n }] = (await r.db.execute<{ n: number }>(sql`select count(*)::int n from ledger_entries where idempotency_key = ${`battle:${bid}:gold`}`)).rows;
    expect(n).toBe(last.status === "won" ? 1 : 0);
    const turns = await r.db.select().from(r.schema.battleTurns).where(eq(r.schema.battleTurns.battleId, bid));
    expect(turns.length).toBeGreaterThan(0);
    // finished battle cannot be played again (no double reward)
    expect((await call(r.battleAct.POST, { token: p.token, id: bid, body: { actionId: randomUUID(), expectedTurn: 0, action: "attack" } })).status).toBe(409);
    const gold = (await profile(p.token)).balances.gold;
    expect(gold).toBe(100 + (last.status === "won" ? last.rewards.gold : 0));
  });

  it("rejects invalid actions and other players' battles", async () => {
    const a = await withStarter(base + 41);
    const b = await withStarter(base + 42);
    const bid = (await call(r.battles.POST, { token: a.token, body: { monsterId: a.monsterId } })).body.id;
    expect((await call(r.battleAct.POST, { token: a.token, id: bid, body: { action: "nuke" } })).status).toBe(400);
    expect((await call(r.battleAct.POST, { token: b.token, id: bid, body: { actionId: randomUUID(), expectedTurn: 0, action: "attack" } })).status).toBe(404);
    expect((await call(r.battles.POST, { token: b.token, body: { monsterId: a.monsterId } })).status).toBe(404);
    const first = await call(r.battleAct.POST, { token: a.token, id: bid, body: { actionId: randomUUID(), expectedTurn: 0, action: "skill" } });
    if (first.body.status === "active") {
      expect((await call(r.battleAct.POST, { token: a.token, id: bid, body: { actionId: randomUUID(), expectedTurn: first.body.turn, action: "skill" } })).status).toBe(409);
    }
  });
});

describe("evolution", () => {
  it("enforces ownership, level and cost; charges exactly once", async () => {
    const a = await withStarter(base + 50);
    const b = await withStarter(base + 51);
    expect((await call(r.evolve.POST, { token: a.token, id: a.monsterId })).body.error).toBe("level_too_low");
    expect((await call(r.evolve.POST, { token: b.token, id: a.monsterId })).status).toBe(404);
    await r.db.update(r.schema.playerMonsters).set({ level: 16 }).where(eq(r.schema.playerMonsters.id, a.monsterId));
    // 100 gold only -> not enough for 500
    expect((await call(r.evolve.POST, { token: a.token, id: a.monsterId })).status).toBe(402);
    await credit(a.id, "gold", 450);
    const ok = await call(r.evolve.POST, { token: a.token, id: a.monsterId });
    expect(ok.status).toBe(200);
    expect(ok.body.speciesId).toBe("fire_2");
    expect((await profile(a.token)).balances.gold).toBe(50);
    expect((await call(r.evolve.POST, { token: a.token, id: a.monsterId })).body.error).toBe("level_too_low");
  });
});

describe("Telegram Stars payments", () => {
  async function order(p: { id: string; tg: number }, productId = "crystals_small", amount = 50) {
    const payload = randomUUID();
    const [o] = await r.db.insert(r.schema.paymentOrders).values({ playerId: p.id, telegramUserId: p.tg, productId, payload, amount, productSnapshot: { name: "Test", grants: { crystals: 100 }, starsPrice: amount } }).returning();
    return o;
  }
  const sp = (o: { payload: string; amount: number }, tg: number, charge: string) => ({
    telegramUserId: tg, payload: o.payload, totalAmount: o.amount, currency: "XTR", chargeId: charge,
  });

  it("does not deliver on invoice creation, delivers once on confirmed payment", async () => {
    const p = await newPlayer(base + 60);
    await r.db.insert(r.schema.products).values({ id: "crystals_small", name: "x", description: "x", starsPrice: 50, grants: { crystals: 100 } }).onConflictDoNothing();
    const o = await order(p);
    expect((await profile(p.token)).balances.crystals).toBe(0); // invoice alone grants nothing
    expect(await r.pay.validatePreCheckout({ id: "1", from: { id: p.tg }, currency: "XTR", total_amount: 50, invoice_payload: o.payload })).toBeNull();
    expect(await r.pay.validatePreCheckout({ id: "1", from: { id: p.tg }, currency: "XTR", total_amount: 1, invoice_payload: o.payload })).toMatch(/mismatch/i);
    expect(await r.pay.validatePreCheckout({ id: "1", from: { id: p.tg + 1 }, currency: "XTR", total_amount: 50, invoice_payload: o.payload })).toMatch(/another user/i);

    const charge = `ch_${randomUUID()}`;
    const results = await Promise.all([1, 2, 3].map(() => r.pay.confirmStarsPayment(sp(o, p.tg, charge))));
    expect(results.filter((x) => x === "confirmed")).toHaveLength(1);
    expect(results.filter((x) => x === "duplicate")).toHaveLength(2);
    expect((await profile(p.token)).balances.crystals).toBe(100);
    expect(await r.pay.confirmStarsPayment(sp(o, p.tg, `ch_${randomUUID()}`))).toBe("duplicate");
    expect((await profile(p.token)).balances.crystals).toBe(100);
    const [row] = await r.db.select().from(r.schema.paymentOrders).where(eq(r.schema.paymentOrders.id, o.id));
    expect(row.status).toBe("confirmed");
    expect(row.confirmedAt).not.toBeNull();
    await expect(r.db.update(r.schema.paymentOrders).set({ status: "pending" }).where(eq(r.schema.paymentOrders.id, o.id))).rejects.toThrow();
  });

  it("rejects payments from another user or with another amount, unknown payloads", async () => {
    const p = await newPlayer(base + 61);
    const o = await order(p);
    expect(await r.pay.confirmStarsPayment({ ...sp(o, p.tg + 5, "c1") })).toBe("rejected");
    const o2 = await order(p);
    expect(await r.pay.confirmStarsPayment({ ...sp(o2, p.tg, "c2"), totalAmount: 1 })).toBe("rejected");
    expect(await r.pay.confirmStarsPayment({ ...sp(o, p.tg, "c3"), payload: "nope" })).toBe("unknown_order");
    expect((await profile(p.token)).balances.crystals).toBe(0);
  });

  it("webhook requires the secret and ignores replayed updates", async () => {
    const p = await newPlayer(base + 62);
    const o = await order(p);
    const upd = {
      update_id: base + 777, message: { chat: { id: p.tg }, from: { id: p.tg }, successful_payment: {
        currency: "XTR", total_amount: 50, invoice_payload: o.payload, telegram_payment_charge_id: `ch_${randomUUID()}` } },
    };
    expect((await call(r.webhook.POST, { body: upd })).status).toBe(401);
    expect((await call(r.webhook.POST, { body: upd, headers: { "x-telegram-bot-api-secret-token": "bad" } })).status).toBe(401);
    const h = { "x-telegram-bot-api-secret-token": WEBHOOK };
    await r.db.delete(r.schema.telegramUpdates).where(eq(r.schema.telegramUpdates.updateId, upd.update_id));
    expect((await call(r.webhook.POST, { body: upd, headers: h })).status).toBe(200);
    expect((await profile(p.token)).balances.crystals).toBe(100);
    const replay = await call(r.webhook.POST, { body: upd, headers: h });
    expect(replay.body.replay).toBe(true);
    expect((await profile(p.token)).balances.crystals).toBe(100);
  });
});

describe("admin authorization, bans and audit", () => {
  it("only configured admins pass; privileged actions are audited", async () => {
    const admin = await newPlayer(ADMIN_TG);
    const user = await newPlayer(base + 70);
    expect((await call(r.adminMetrics.GET, { method: "GET" })).status).toBe(401);
    expect((await call(r.adminMetrics.GET, { method: "GET", token: user.token })).status).toBe(403);
    const m = await call(r.adminMetrics.GET, { method: "GET", token: admin.token });
    expect(m.status).toBe(200);
    expect(m.body.players).toBeGreaterThan(0);

    // non-admin cannot ban or grant
    expect((await call(r.adminBan.POST, { token: user.token, id: admin.id, body: { banned: true, reason: "abuse!" } })).status).toBe(403);
    expect((await call(r.adminGrant.POST, { token: user.token, body: { playerId: user.id, currency: "gold", amount: 999, reason: "free", requestId: "req-12345678" } })).status).toBe(403);

    const grant = { playerId: user.id, currency: "gold", amount: 77, reason: "support", requestId: `req-${randomUUID()}` };
    expect((await call(r.adminGrant.POST, { token: admin.token, body: grant })).status).toBe(200);
    expect((await call(r.adminGrant.POST, { token: admin.token, body: grant })).status).toBe(200); // idempotent replay
    expect((await profile(user.token)).balances.gold).toBe(77);

    expect((await call(r.adminBan.POST, { token: admin.token, id: admin.id, body: { banned: true, reason: "oops me" } })).status).toBe(400);
    expect((await call(r.adminBan.POST, { token: admin.token, id: user.id, body: { banned: true, reason: "cheating" } })).status).toBe(200);
    expect((await call(r.me.GET, { method: "GET", token: user.token })).status).toBe(403); // existing session dies immediately
    expect((await call(r.auth.POST, { body: { initData: initFor(user.tg) } })).status).toBe(403);
    expect((await call(r.adminBan.POST, { token: admin.token, id: user.id, body: { banned: false, reason: "appeal ok" } })).status).toBe(200);
    expect((await call(r.me.GET, { method: "GET", token: user.token })).status).toBe(200);

    const logs = await r.db.select().from(r.schema.auditLogs).where(eq(r.schema.auditLogs.actorPlayerId, admin.id));
    const actions = logs.map((l) => l.action);
    expect(actions).toEqual(expect.arrayContaining(["admin.adjust_balance", "admin.ban", "admin.unban"]));
    expect(actions.filter((a) => a === "admin.adjust_balance")).toHaveLength(1);
  });
});

describe("rate limiting & database security (RLS)", () => {
  it("blocks after the limit", async () => {
    const key = `rl:${randomUUID()}`;
    await r.rl.rateLimit(key, 2, 60);
    await r.rl.rateLimit(key, 2, 60);
    await expect(r.rl.rateLimit(key, 2, 60)).rejects.toMatchObject({ status: 429 });
  });

  it("every public table has RLS enabled", async () => {
    const res = await r.db.execute<{ tablename: string; rowsecurity: boolean }>(
      sql`select tablename, rowsecurity from pg_tables where schemaname = 'public' and tablename not like '\\_%' and tablename <> '__drizzle_migrations'`,
    );
    expect(res.rows.length).toBeGreaterThan(10);
    expect(res.rows.filter((t) => !t.rowsecurity).map((t) => t.tablename)).toEqual([]);
  });
});


describe("pve-v2 concurrency and requests", () => {
 it("requires actionId and expectedTurn, deduplicates a repeated response and rejects stale turns", async () => {
  const p = await withStarter(base + 91);
  const b = await call(r.battles.POST, { token: p.token, body: { monsterId: p.monsterId } });
  expect((await call(r.battleAct.POST, { token: p.token, id: b.body.id, body: { action: "attack" } })).status).toBe(400);
  const body = { action: "guard", actionId: randomUUID(), expectedTurn: 0 };
  const results = await Promise.all([1,2,3].map(() => call(r.battleAct.POST, { token: p.token, id: b.body.id, body })));
  expect(results.every(x => x.status === 200)).toBe(true);
  expect(results[0].body).toEqual(results[1].body);
  const [stored] = await r.db.select().from(r.schema.battles).where(eq(r.schema.battles.id, b.body.id));
  expect(stored.turnNo).toBe(1);
  expect((await call(r.battleAct.POST, { token: p.token, id: b.body.id,
    body: { action: "attack", actionId: randomUUID(), expectedTurn: 0 } })).body.error).toBe("stale_turn");
  expect((await call(r.battleAct.POST, { token: p.token, id: b.body.id,
    body: { ...body, action: "attack" } })).body.error).toBe("action_id_reused");
 });
 it("serializes battle starts even with different monsters", async () => {
  const p = await withStarter(base + 92);
  const [m] = await r.db.insert(r.schema.playerMonsters).values({ playerId: p.id, speciesId: "water_1" }).returning();
  const starts = await Promise.all([p.monsterId,m.id].map(monsterId => call(r.battles.POST, { token: p.token, body: { monsterId } })));
  expect(starts[0].body.id).toBe(starts[1].body.id);
 });
 it("guarantees first capture and never gives two monsters on retry", async () => {
  const p = await withStarter(base + 93);
  const start = await call(r.battles.POST, { token: p.token, body: { monsterId: p.monsterId } });
  // Fixture isolates capture ownership/idempotency from combat balance.
  await r.db.update(r.schema.battles).set({ status: "won", finishedAt: new Date() }).where(eq(r.schema.battles.id,start.body.id));
  const { captureMonster } = await import("@/server/adventure");
  const results = await Promise.all([captureMonster(p.id,start.body.id),captureMonster(p.id,start.body.id)]);
  expect(results[0]).toEqual(results[1]);
  expect(results[0]).toMatchObject({ success: true, chance: 1 });
  expect((await profile(p.token)).monsters).toHaveLength(2);
 });
 it("persists the draw instead of recording a loss", async () => {
  const p = await withStarter(base + 94);
  const start = await call(r.battles.POST, { token: p.token, body: { monsterId: p.monsterId } });
  const state = { player: { ...start.body.player, hp: 10000, maxHp: 10000, atk: 1 },
    enemy: { ...start.body.enemy, hp: 10000, maxHp: 10000, atk: 1 }, turn: 39, winner: null };
  await r.db.update(r.schema.battles).set({ state, turnNo: 39 }).where(eq(r.schema.battles.id,start.body.id));
  const result = await call(r.battleAct.POST, { token: p.token, id: start.body.id,
    body: { action: "guard", actionId: randomUUID(), expectedTurn: 39 } });
  expect(result.body.status).toBe("draw");
  expect(result.body.rewards).toBeNull();
 });
});
