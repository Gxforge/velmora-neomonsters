# Velmora — integración PvE v2 (sin validar en runtime)

Entrega modificada a partir del ZIP adjunto y del diagnóstico `pasted-text.txt`.
Consulta **INTEGRACION.md** para el alcance exacto, pendientes y validación.

## Puesta en marcha

1. Instala Node.js 22 y configura `.env.local` a partir de `.env.example`.
2. Ejecuta `npm install --package-lock-only`, revisa y versiona `package-lock.json`.
3. Ejecuta `npm ci` y `npm run db:migrate` con una base de staging respaldada.
4. Ejecuta `npm run typecheck`, `npm run lint`, `npm test`, `npm run assets:audit` y `npm run build`.
5. Configura el bot, URL pública y webhook según `TELEGRAM.md` y `DEPLOYMENT.md`.

El shell opcional `scripts/bootstrap.sh` ejecuta los pasos de instalación y verificación;
la migración requiere `DATABASE_URL` en el entorno o en `.env`.

No hay lockfile generado: el entorno de edición carece de Node/npm y red.
No se garantiza una instalación reproducible hasta generar y verificar ese archivo.
La CI usa `npm ci` cuando existe; provisionalmente usa `npm install` si falta.

## Incluido en código

Colección seleccionable, captura postvictoria, bestiario, misiones reclamables,
tres regiones con jefes y desbloqueos, cristales gratuitos, habilidades elementales,
defensa prioritaria, empates, acciones deduplicadas y recuperación de estado,
arena visual, sonido opcional, costes de evolución y compras consultables.

**PvP, matchmaking, temporadas y cooperativo no están implementados.**
Los PNG incluidos son arte procedural provisional, no arte final recuperado.
Ningún pago real, despliegue o prueba npm se ha ejecutado en esta entrega.

---

## Documentación original (puede describir el prototipo anterior)

# Velmora

Telegram Mini App: collect, evolve and battle elemental monsters. Next.js (App Router) + Postgres (Supabase) + Drizzle.

> **Status: pre-production foundation. NOT production-ready.** See the status table below; anything not listed as IMPLEMENTED must not be assumed to work.

## Status

| Area | Status | Notes |
|---|---|---|
| Telegram login (initData HMAC validation, signed session) | IMPLEMENTED | `src/lib/telegram`, `src/server/auth.ts` |
| Telegram identity separated from game account | IMPLEMENTED | `telegram_identities` -> `players` |
| Server-side economy (ledger, idempotency, no negative balances) | IMPLEMENTED | `src/server/economy.ts` |
| PvE combat, server-authoritative, replayable by seed | IMPLEMENTED | `src/lib/game/combat.ts` |
| Monster catalog (6 lines x 3 stages, stats) + evolution rules | IMPLEMENTED | rules/stats are a first balance pass, untuned |
| Telegram Stars payments (verified, idempotent) | PARTIAL | code + tests done; needs deployed webhook + real-payment test |
| Admin API + console (role checked in backend, audit logs, bans) | PARTIAL | basic; no economy/payment dashboards yet |
| Rate limiting, audit logs, structured logs | IMPLEMENTED | no external error tracker yet (PARTIAL) |
| Supabase staging + production (migrations, RLS) | IMPLEMENTED | see DATABASE.md |
| CI (lint, typecheck, tests, build, secret scan) | IMPLEMENTED | `.github/workflows/ci.yml` |
| Vercel auto-deploy from GitHub | NOT IMPLEMENTED | the supplied Vercel token was rejected as invalid (see DEPLOYMENT.md) |
| Evolution design sheets (6 lines, 3 stages in one image, <=20 colours) | PARTIAL | AI-generated, audited; see ASSET_AUDIT.md |
| Production sprite sheets (idle/attack/hit/faint/evolution) | NOT IMPLEMENTED | |
| Icon set | NOT IMPLEMENTED | UI currently uses emoji as a stopgap |
| Licensed audio | NOT IMPLEMENTED | no audio shipped; see CREDITS.md |
| Real PvP (matchmaking, rooms, turn timeouts, reconnection) | NOT IMPLEMENTED | UI says PvP is unavailable |
| TON deposits/withdrawals | NOT IMPLEMENTED | intentionally; see PAYMENTS.md |
| Supabase Storage, Supabase Auth | NOT IMPLEMENTED | not needed yet |
| E2E browser tests | NOT IMPLEMENTED | unit + integration tests exist |

## Development

```bash
npm install
cp .env.example .env.local   # fill with DEVELOPMENT/staging values, never production
npm run db:migrate           # applies supabase/migrations to DATABASE_URL
npm test                     # unit + integration (needs a local Postgres)
npm run dev
```

Scripts: `lint`, `typecheck`, `test`, `build`, `db:generate`, `db:migrate`, `assets:process`, `assets:audit`, `audit:forbidden`, `telegram:webhook`.

Branches: `main` = production, `develop` = staging/preview.

## Documentation

ARCHITECTURE.md · DEPLOYMENT.md · DATABASE.md · SECURITY.md · PAYMENTS.md · TELEGRAM.md · ASSETS.md · ASSET_AUDIT.md · CREDITS.md
