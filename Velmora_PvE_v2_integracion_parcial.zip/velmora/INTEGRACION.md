# Integración del diagnóstico — estado real de la entrega

## Alcance y advertencias

Fuente de requisitos: `pasted-text.txt`, apartados 1–9 y selección final.
Esta entrega modifica el código original: no es una aplicación desplegada ni certificada.
No se ha podido ejecutar TypeScript, ESLint, Vitest, Next.js, npm ni PostgreSQL:
el entorno de edición no tiene Node/npm, servicios de base de datos ni acceso a red.
Se realizaron comprobaciones estáticas de rutas/importaciones locales, assets,
manifiestos, JSON, presencia de migración y estructura del ZIP, con Python/Pillow.
Las pruebas añadidas son **pruebas por ejecutar**, no resultados aprobados.

No se implementó todo el catálogo: el documento contiene alternativas de diseño
y expansiones que requieren varias iteraciones. Esta matriz lo hace explícito.

## Matriz de cobertura

| Recomendación del diagnóstico | Estado | Implementación / siguiente paso |
|---|---|---|
| PNG faltantes y fallback | Código incluido | Seis hojas procedurales provisionales y Creature.tsx; sustituir por arte final |
| Auditoría de archivos esperados y dimensiones | Código incluido | scripts/assets/audit-palette.ts |
| Lockfile reproducible | Pendiente | No se inventó un lockfile; generar con npm y versionar. CI tiene bootstrap condicional |
| Captura y adquisición jugable | Código incluido | Captura después de victoria salvaje, primer intento 100%, posteriores 65%, un intento persistido por batalla |
| Selección de cualquier criatura | Código incluido | Collection.tsx; selección válida solo para nuevos combates |
| Equipo activo y dos reservas | Pendiente | Diseñar snapshots, cambios de criatura y validaciones de equipo |
| Bestiario y ubicaciones | Código incluido | Especies vistas en batallas y poseídas; no hay historial independiente de evoluciones anteriores |
| Evolución informativa | Código incluido | Requisitos, costes, siguiente especie, bases estadísticas, recursos faltantes y confirmación |
| Roles y habilidades diferenciadas | Código incluido | Seis efectos elementales; los roles son etiquetas y perfiles existentes, no talentos individuales |
| Especializaciones y reinicio | Pendiente | Diseñar talentos y coste de reinicio |
| Liberación de duplicados | Pendiente | Impedir liberación del último inicial o criatura vinculada a combate |
| Defensa explícita y velocidad | Código incluido | Prioridad de guardia, −50% durante la ronda; pruebas para criatura lenta |
| Cuatro estados cortos | Código incluido | Quemadura, escudo, prisa, debilidad; agua cura y luz limpia |
| Intenciones enemigas | Código incluido | Patrón determinista anticipado; no simulación de intención aleatoria |
| IA por arquetipos / jefes por fases | Parcial | Patrón general + más vida para jefes; no fases o arquetipos distintos |
| Información táctica | Parcial | Afinidad, orden, cooldown y duración de estados; falta rango estimado de daño |
| Límite de 40 turnos y empate | Código incluido | Estado draw en API/SQL/UI; quemaduras simultáneas también empatan |
| Tutorial jugable | Parcial | Pasos visibles, inicial y primera captura garantizada; no combate guiado con acciones restringidas |
| Tres regiones y jefes | Código incluido | Desbloqueo por jefe previo, nivel mínimo y bonus de primera victoria |
| Mapa visual por biomas | Parcial | Lista de regiones; no mapa ilustrado |
| Normal / difícil / desafío | Código incluido | Nivel y recompensas definidos en servidor y visibles antes de comenzar |
| Misiones | Código incluido | Cuatro objetivos reclamables con deduplicación |
| Desafíos semanales | Pendiente | Rotación versionada y entrega única por semana |
| Expediciones y mazmorras | Pendiente | Nuevos estados persistidos y economía secundaria |
| Ritmo de XP | Código incluido, sin balance validado | 40 + 2 × nivel²; bonus de jefes; simular y probar con jugadores |
| Evitar salto de etapa enemigo | Código incluido | Enemigos salvajes no superan etapa del combatiente; jefes son retos explícitos |
| Inicio / colección / aventura / arena / tienda | Parcial | Cinco secciones funcionales; Combate es PvE, no se anuncia Arena PvP inexistente |
| Arena visual | Código incluido, provisional | Criaturas y escenario CSS; no dirección artística final |
| Animaciones de ataque/impacto/defensa/derrota/evolución | Parcial | Impacto CSS y secuencia de HP; sin sets de sprites o cinemática de evolución |
| Secuenciación de eventos | Código incluido | Animación antes del estado final; reduced motion opcional |
| Números flotantes | Pendiente | Daño, críticos y afinidad se registran en texto accesible |
| Audio | Código incluido, básico | Tres efectos originales WAV, activación voluntaria; falta música |
| Estados de carga | Código incluido | Contador de solicitudes, bloqueo local de acción y recuperación explícita |
| Skeletons / conectividad avanzada | Parcial | Mensajes de carga/reintento; no skeletons o cola offline |
| Accesibilidad, zoom y safe areas | Código incluido, sin auditoría dispositivo | Botones mínimos, foco visible, progress, aria-live, texto para estados, zoom permitido |
| Localización ES/EN mediante claves | Pendiente | Nueva UI en español; no diccionario bilingüe, admin sigue en inglés |
| Ajustes | Parcial | Sonido/vibración/movimiento reducido durante sesión; falta persistencia y tema |
| Identidad e iconos coherentes | Parcial | CSS común y criaturas provisionales; falta set de iconos final |
| Duelos amistosos / salas / plazos | Pendiente | No se crean pantallas vacías ni se simula PvP |
| Reconexión y abandono PvE | Código incluido | Recuperación de batalla activa y abandono sin recompensa |
| Matchmaking / rating / temporadas | Pendiente | Requiere protocolo multiusuario, balance y cuentas abusivas |
| Niveles normalizados competitivos | Pendiente | No existe competitivo en esta entrega |
| Cooperativo | Pendiente | Contribuciones y recompensas compartidas verificables |
| Enlaces profundos / invitaciones Telegram | Pendiente | Bot original conservado; no se inventa una integración funcional |
| BackButton / tema / zonas seguras Telegram | Parcial | Safe areas CSS; falta navegación SDK y pruebas de WebView |
| Vibración opcional | Parcial | API de navegador, no HapticFeedback Telegram; puede no funcionar en WebView |
| Compartir logros / referidos / notificaciones | Pendiente | Requiere permisos voluntarios y deduplicación de recompensa |
| Ayuda / soporte / soporte de pagos bot | Pendiente | Configurar canal real de soporte; no se inventa un contacto |
| Progresión sin pago obligatorio | Código incluido | 1 cristal por victoria + misiones y primeros jefes; se mantienen costes de evolución |
| Materiales de evolución | Pendiente | No se introdujo una moneda sin infraestructura; se conservan oro/cristales |
| Cosméticos / fondos / emotes | Pendiente | Tienda original de recursos conservada; no hay clasificatorias pagables |
| Compras consultables / historial | Código incluido | GET payments/history + polling acotado y actualización manual |
| Expiración de órdenes | Parcial | Rechazo de precheckout después de 24h; filas no se cambian por tarea programada |
| Instantánea de producto | Código incluido | Grants de la orden, no del catálogo actual |
| Conciliación | Parcial | Métrica de órdenes confirmadas sin asientos; falta panel y proceso de reparación auditado |
| Devoluciones | Pendiente | Requiere política, permisos y procedimiento real, no reversión automática |
| Componentes | Parcial | Colección, criatura y aventura separados; arena/tienda aún en página principal |
| Caché y contratos compartidos | Parcial | Tipos de combate/colección compartidos; no librería de query cache ni esquemas de respuesta completos |
| Versionado de reglas | Parcial | Identificador pve-v2 guardado, legacy-v1 bloqueado; no ejecutor multiversión histórico |
| Una batalla activa por jugador | Código incluido | Bloqueo de jugador + índice único parcial |
| Seguridad CSP/tokens | Pendiente de auditoría | Autenticación y RLS existentes conservadas; no certificación de seguridad |
| Observabilidad externa | Pendiente | Auditoría y logger local existentes; configurar proveedor y alertas |
| Administración | Parcial | Métricas agregadas + detección de entrega faltante; no nuevos paneles operativos completos |
| E2E / concurrencia / reintentos / empates | Parcial | Pruebas unitarias e integración añadidas; no E2E de navegador y ninguna ejecutada aquí |
| Métricas D1/D7 y abandono | Pendiente | Sin eventos analíticos completos ni cohortes |
| Capturas / turnos / evoluciones / pagos | Parcial | Métricas SQL agregadas; primera captura usa finished_at como aproximación, no timestamp exacto de captura |

## Migración y compatibilidad

Nueva migración: `supabase/migrations/20261002050300_pve_v2.sql`.

- Respaldar DB y aplicar primero en staging con backend detenido.
- La migración se detiene si hay varias batallas activas por jugador. Resolverlas
  explícitamente y con auditoría; no las descarta silenciosamente.
- Las partidas anteriores se marcan `legacy-v1`. Se pueden consultar o abandonar;
  no se resuelven con reglas nuevas. La UI indica reiniciar.
- Las órdenes anteriores se rellenan desde el catálogo DB actual: no se puede
  reconstruir una instantánea histórica desconocida. Revisar pendientes antes de abrir pagos.
- Nuevos POST de acciones **requieren** actionId UUID y expectedTurn (número de rondas ya resueltas).
  Una repetición con el mismo contenido devuelve la respuesta guardada incluso si finalizó la batalla.
  Una reutilización con contenido diferente devuelve action_id_reused.
- No hay modificación de la DB real ni credenciales incluidas en el ZIP.
- Las nuevas tablas mantienen RLS sin políticas públicas; el backend usa conexión privilegiada.

## Validación necesaria antes de producción

1. Generar lockfile y ejecutar typecheck/lint/test/assets:audit/build.
2. Confirmar que las versiones npm originales están publicadas y son compatibles.
3. Aplicar las tres migraciones a DB vacía y la nueva a copia de staging.
4. Probar dos pestañas, doble clic, respuestas perdidas, reconexión y abandono.
5. Verificar primer encuentro, captura repetida, reclamación concurrente y costes de evolución.
6. Probar jefe derrotado dos veces: bonus solo la primera vez y desbloqueo persistido.
7. Revisar balance: vidas de jefes, curación, estados y aceleración XP.
8. Probar Telegram Android/iOS/escritorio, tamaño de texto y lector de pantalla.
9. Probar Stars en entorno apropiado: cambio de catálogo tras factura, duplicados,
   webhook retrasado, importe incorrecto y conciliación.
10. Implementar soporte de pagos y devolución antes de cobrar públicamente.

## Secuencia pendiente

Cerrar Fase 0 con lockfile y pruebas; completar pulido de Fase 1;
construir duelos amistosos con autoridad compartida, turnos y reconexión en Fase 2;
solo después introducir clasificatorias, cosméticos y cooperación de Fase 3.
