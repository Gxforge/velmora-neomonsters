# Architecture

```
Telegram client ──(Mini App webview)──> Next.js frontend (src/app, thin client)
        │                                       │ Bearer session token
        │ bot updates (secret header)           ▼
        └────────> /api/telegram/webhook   Route handlers (src/app/api)
                                                │ zod validation, rate limit, auth
                                                ▼
                                  Services (src/server)  ──>  Postgres (Supabase)
                                                │
                                  Pure game logic (src/lib/game)
```

| Layer | Location | Status |
|---|---|---|
| Frontend (Mini App UI, admin UI) | `src/app`, `src/lib/client` | IMPLEMENTED (minimal) |
| Backend routes | `src/app/api/**` | IMPLEMENTED |
| Services (auth, economy, battles, monsters, payments, admin) | `src/server` | IMPLEMENTED |
| Pure game logic (combat, progression, catalog, rng) | `src/lib/game` | IMPLEMENTED |
| Telegram identity/validation | `src/lib/telegram`, `src/server/auth.ts` | IMPLEMENTED |
| Database + migrations | `src/db`, `supabase/migrations` | IMPLEMENTED |
| Assets pipeline | `scripts/assets`, `public/assets` | PARTIAL |
| Analytics | `/api/admin/metrics` (counts only) | PARTIAL |

## Principles
- The client never decides balances, damage, rewards, rarity, ownership, purchase results or winners. It sends an *intent* (e.g. `{action:"attack"}`); the server computes everything.
- All balance changes go through `applyLedger` (transactional, row-locked, idempotent, append-only ledger).
- Combat is deterministic from a per-battle seed stored server-side, so any battle can be replayed and audited (`battle_turns`).
- Telegram identity (`telegram_identities`) is separate from the game account (`players`) so other identity providers can be added later.
- Sessions are stateless signed tokens sent in the `Authorization` header; ban/role state is re-read from the DB on every request.

## Known limits
- Rate limiter is a fixed window in Postgres (simple, not a replacement for edge/WAF protection).
- PvE only. PvP needs additional tables (matches, queue) and a realtime transport; NOT IMPLEMENTED.
