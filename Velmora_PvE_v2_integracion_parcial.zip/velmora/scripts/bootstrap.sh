#!/usr/bin/env bash
set -euo pipefail
npm install --package-lock-only
npm ci
npm run db:migrate
npm run typecheck
npm run lint
npm test
npm run assets:audit
npm run build
# Review and commit package-lock.json, then CI uses npm ci automatically.
