import sharp from "sharp";

export const MAX_COLOURS = 20;

export type Raw = { data: Buffer; width: number; height: number };

export async function readRaw(input: string | Buffer): Promise<Raw> {
  const { data, info } = await sharp(input).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  return { data, width: info.width, height: info.height };
}

/** Counts distinct VISIBLE colours (alpha > 0). Transparency is not counted. */
export function countColours(raw: Raw): { count: number; hasPartialAlpha: boolean } {
  const set = new Set<number>();
  let partial = false;
  for (let i = 0; i < raw.data.length; i += 4) {
    const a = raw.data[i + 3];
    if (a === 0) continue;
    if (a !== 255) partial = true;
    set.add((raw.data[i] << 16) | (raw.data[i + 1] << 8) | raw.data[i + 2]);
  }
  return { count: set.size, hasPartialAlpha: partial };
}
