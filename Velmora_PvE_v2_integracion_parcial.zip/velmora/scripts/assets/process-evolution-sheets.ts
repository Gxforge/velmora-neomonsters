/**
 * Pixel-art pipeline for evolution design sheets:
 *   AI source (jpeg/png) -> nearest-neighbour downscale -> background removal
 *   -> binary alpha (no anti-aliasing) -> palette quantisation (<=20, no dithering)
 *   -> PNG export -> re-read and COUNT visible colours -> reject if > 20.
 *
 *   npm run assets:process
 */
import { mkdirSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import sharp from "sharp";
import { MAX_COLOURS, countColours, readRaw } from "./lib";

const SRC = "art/source";
const OUT = "public/assets/evolution";
const TARGET_HEIGHT = 224; // consistent pixel density across all lines
const BG_TOLERANCE = 42;

function removeBackground(data: Buffer, w: number, h: number) {
  // dominant border colours = background (banded backgrounds have 2-3)
  const hist = new Map<number, { n: number; r: number; g: number; b: number }>();
  const sample = (x: number, y: number) => {
    const i = (y * w + x) * 4;
    const key = ((data[i] >> 4) << 8) | ((data[i + 1] >> 4) << 4) | (data[i + 2] >> 4);
    const e = hist.get(key) ?? { n: 0, r: 0, g: 0, b: 0 };
    e.n++; e.r += data[i]; e.g += data[i + 1]; e.b += data[i + 2];
    hist.set(key, e);
  };
  for (let x = 0; x < w; x++) { sample(x, 0); sample(x, h - 1); }
  for (let y = 0; y < h; y++) { sample(0, y); sample(w - 1, y); }
  const total = 2 * (w + h);
  const bgs = [...hist.values()]
    .filter((e) => e.n / total > 0.04)
    .map((e) => [e.r / e.n, e.g / e.n, e.b / e.n]);

  const isBg = new Uint8Array(w * h);
  for (let p = 0; p < w * h; p++) {
    const i = p * 4;
    isBg[p] = bgs.some(([r, g, b]) => Math.hypot(data[i] - r, data[i + 1] - g, data[i + 2] - b) <= BG_TOLERANCE) ? 1 : 0;
  }

  // connected components of bg-like pixels; drop border-connected ones and big enclosed pockets
  const seen = new Uint8Array(w * h);
  const remove = new Uint8Array(w * h);
  for (let s = 0; s < w * h; s++) {
    if (!isBg[s] || seen[s]) continue;
    const stack = [s];
    const comp: number[] = [];
    let touches = false;
    seen[s] = 1;
    while (stack.length) {
      const p = stack.pop()!;
      comp.push(p);
      const x = p % w, y = (p / w) | 0;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) touches = true;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
        const q = ny * w + nx;
        if (isBg[q] && !seen[q]) { seen[q] = 1; stack.push(q); }
      }
    }
    if (touches || comp.length >= 40) for (const p of comp) remove[p] = 1;
  }
  for (let p = 0; p < w * h; p++) data[p * 4 + 3] = remove[p] ? 0 : 255; // binary alpha
}

async function main() {
  mkdirSync(OUT, { recursive: true });
  const files = readdirSync(SRC).filter((f) => /^evolution_.*\.png$/.test(f)).sort();
  const manifest: Record<string, unknown>[] = [];
  let failed = 0;

  for (const f of files) {
    const line = f.replace(/^evolution_|\.png$/g, "");
    const meta = await sharp(join(SRC, f)).metadata();
    const width = Math.round(((meta.width ?? 1) / (meta.height ?? 1)) * TARGET_HEIGHT);
    const small = await readRaw(
      await sharp(join(SRC, f)).resize(width, TARGET_HEIGHT, { kernel: "nearest" }).png().toBuffer(),
    );
    removeBackground(small.data, small.width, small.height);

    let colours = MAX_COLOURS;
    let out: Buffer | null = null;
    let count = 999;
    while (colours >= 8) {
      out = await sharp(small.data, { raw: { width: small.width, height: small.height, channels: 4 } })
        .png({ palette: true, colours, dither: 0, effort: 10, compressionLevel: 9 })
        .toBuffer();
      const check = countColours(await readRaw(out));
      count = check.count;
      if (count <= MAX_COLOURS && !check.hasPartialAlpha) break;
      colours--;
    }
    const ok = out !== null && count <= MAX_COLOURS;
    if (!ok) { failed++; console.error(`REJECTED ${line}: ${count} colours`); continue; }
    writeFileSync(join(OUT, `${line}.png`), out!);
    manifest.push({ line, file: `${line}.png`, width: small.width, height: small.height, colours: count, source: `${SRC}/${f}` });
    console.log(`ok ${line}: ${small.width}x${small.height}, ${count} colours`);
  }
  writeFileSync(join(OUT, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n");
  if (failed) process.exit(1);
}

void main();
