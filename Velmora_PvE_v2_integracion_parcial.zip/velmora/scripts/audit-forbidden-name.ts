/**
 * Repository audit: fails (exit 1) if tracked files contain the retired
 * project name or anything that looks like a credential.
 * The pattern is assembled at runtime so this file does not contain the name.
 */
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";

const retired = new RegExp(["neo", "[ _-]?", "mon", "ster"].join(""), "i");
const secrets: [string, RegExp][] = [
  ["github token", /gh[pousr]_[A-Za-z0-9]{30,}/],
  ["vercel token", /vc[a-z]_[A-Za-z0-9]{30,}/],
  ["supabase token", /sbp_[A-Za-z0-9]{30,}/],
  ["telegram bot token", /\b\d{8,10}:AA[A-Za-z0-9_-]{30,}/],
  ["jwt", /eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}/],
];

const files = execFileSync("git", ["ls-files", "--cached", "--others", "--exclude-standard"], { encoding: "utf8" })
  .split("\n")
  .filter(Boolean);

let bad = 0;
for (const f of files) {
  if (retired.test(f)) { console.error(`retired name in path: ${f}`); bad++; }
  if (/\.(png|jpe?g|webp|ogg|opus|wav|mp3|lock)$|package-lock\.json$/.test(f)) continue;
  let text: string;
  try { text = readFileSync(f, "utf8"); } catch { continue; }
  if (retired.test(text)) { console.error(`retired name in content: ${f}`); bad++; }
  for (const [label, re] of secrets) {
    if (re.test(text)) { console.error(`possible ${label} in ${f}`); bad++; }
  }
}
if (bad) { console.error(`audit FAILED (${bad})`); process.exit(1); }
console.log(`audit OK: ${files.length} files, 0 retired-name matches, 0 secrets`);
