/**
 * Applies /supabase/migrations/*.sql in filename order to DATABASE_URL.
 * Tracks applied files in public._velmora_migrations. Idempotent.
 *
 *   DATABASE_URL=... npm run db:migrate
 */
import "dotenv/config";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { Client } from "pg";

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is required");
  const local = /@(127\.0\.0\.1|localhost)[:/]/.test(url);
  const client = new Client({
    connectionString: url,
    ssl: local ? false : { rejectUnauthorized: false },
  });
  await client.connect();
  const host = new URL(url).hostname; // never print credentials
  console.log(`Migrating host=${host}`);

  await client.query(`create table if not exists public._velmora_migrations (
    filename text primary key, applied_at timestamptz not null default now())`);
  const done = new Set(
    (await client.query("select filename from public._velmora_migrations")).rows.map(
      (r) => r.filename as string,
    ),
  );

  const dir = join(process.cwd(), "supabase", "migrations");
  const files = readdirSync(dir)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  for (const file of files) {
    if (done.has(file)) {
      console.log(`skip   ${file}`);
      continue;
    }
    const sqlText = readFileSync(join(dir, file), "utf8").replaceAll(
      "--> statement-breakpoint",
      "",
    );
    try {
      await client.query("begin");
      await client.query(sqlText);
      await client.query("insert into public._velmora_migrations(filename) values ($1)", [file]);
      await client.query("commit");
      console.log(`apply  ${file}`);
    } catch (err) {
      await client.query("rollback");
      console.error(`FAILED ${file}:`, (err as Error).message);
      process.exitCode = 1;
      break;
    }
  }
  await client.query("alter table public._velmora_migrations enable row level security");
  await client.end();
}

main().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
