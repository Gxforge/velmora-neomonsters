/**
 * Registers the bot webhook (run once per environment after deploy):
 *   TELEGRAM_BOT_TOKEN=... TELEGRAM_WEBHOOK_SECRET=... APP_URL=https://... npm run telegram:webhook
 * The token is read from the environment and never printed.
 */
const token = process.env.TELEGRAM_BOT_TOKEN;
const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
const appUrl = process.env.APP_URL;
if (!token || !secret || !appUrl) throw new Error("TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET and APP_URL are required");
if (!appUrl.startsWith("https://")) throw new Error("APP_URL must be https");

async function main() {
  const res = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      url: `${appUrl}/api/telegram/webhook`,
      secret_token: secret,
      allowed_updates: ["message", "pre_checkout_query"],
      max_connections: 20,
    }),
  });
  const data = (await res.json()) as { ok: boolean; description?: string };
  console.log(data.ok ? "webhook registered" : `failed: ${data.description}`);
  if (!data.ok) process.exit(1);
}
void main();
