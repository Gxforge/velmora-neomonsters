# Payments

## Telegram Stars (XTR) — PARTIAL
Code and tests are complete; **no real payment has been made end-to-end yet** because the webhook cannot be registered until the app is deployed (Vercel not connected, see DEPLOYMENT.md).

Flow:
1. `POST /api/payments/stars/invoice` creates `payment_orders(status=pending)` with a random `payload`, then `createInvoiceLink` (currency `XTR`, empty provider token). **Nothing is granted.**
2. Telegram sends `pre_checkout_query`; the server approves only if the order exists, is pending, belongs to that Telegram user and amount/currency match (otherwise it rejects with an error message).
3. Telegram sends `message.successful_payment`; only then `confirmStarsPayment` runs in one transaction: lock order row -> verify user/amount/currency -> mark `confirmed` with `telegram_payment_charge_id` (unique) and `confirmed_at` -> credit goods via ledger with idempotency key `payment:<orderId>:<currency>`.

Stored: transaction/charge id, telegram_user_id, payload, amount, currency, product_id, status, created_at, confirmed_at.

Guarantees (covered by integration tests): concurrent/replayed confirmations deliver once; a different charge id on a confirmed order is logged as a conflict and delivers nothing; wrong user/amount is rejected and flagged for review; webhook replay (same `update_id`) is ignored; confirmed orders cannot revert (DB trigger).

Not implemented: refunds/`refunded_payment` handling and goods clawback (TODO), purchase receipts UI, product pricing tuning (launch prices in `src/lib/game/catalog.ts` are placeholders for balance work).

## TON — NOT IMPLEMENTED (intentionally)
No deposit, withdrawal or balance exists. Before any TON feature: define wallet/network/address validation, limits, double-execution protection, idempotency, on-chain verification in the backend and audit; keep `internal_balance` separate from `blockchain_transaction`/`deposit`/`withdrawal` with states `pending|confirmed|failed|cancelled`. No real-money wagering until real PvP is robust.
