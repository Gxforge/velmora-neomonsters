-- Stop rather than silently discard pre-existing active battles.
DO $$ BEGIN
 IF EXISTS (SELECT player_id FROM battles WHERE status='active' GROUP BY player_id HAVING count(*)>1)
 THEN RAISE EXCEPTION 'Resolve duplicate active battles before applying pve-v2'; END IF;
END $$;
ALTER TABLE battles DROP CONSTRAINT battles_status_chk;
ALTER TABLE battles ADD CONSTRAINT battles_status_chk CHECK(status IN ('active','won','lost','draw','abandoned'));
CREATE UNIQUE INDEX battles_one_active_player ON battles(player_id) WHERE status='active';
ALTER TABLE battles ADD COLUMN region_id text;
ALTER TABLE battles ADD COLUMN boss boolean NOT NULL DEFAULT false;
ALTER TABLE battles ADD COLUMN difficulty text NOT NULL DEFAULT 'normal' CHECK(difficulty IN ('normal','hard','challenge'));
ALTER TABLE battles ADD COLUMN rules_version text NOT NULL DEFAULT 'legacy-v1';
ALTER TABLE battles ADD COLUMN capture_result jsonb;
ALTER TABLE payment_orders ADD COLUMN product_snapshot jsonb;
-- Existing pending orders had no historical snapshot. Backfill from current DB catalog;
-- review these orders before deployment if their original rewards have changed.
UPDATE payment_orders o SET product_snapshot=jsonb_build_object('name',p.name,'grants',p.grants,'starsPrice',o.amount)
FROM products p WHERE p.id=o.product_id;
ALTER TABLE payment_orders ALTER COLUMN product_snapshot SET NOT NULL;
CREATE TABLE battle_actions (
 battle_id uuid NOT NULL REFERENCES battles(id) ON DELETE CASCADE,
 action_id uuid NOT NULL, expected_turn integer NOT NULL, action text NOT NULL,
 response jsonb NOT NULL, PRIMARY KEY(battle_id,action_id));
CREATE TABLE progression_claims (
 player_id uuid NOT NULL REFERENCES players(id), claim_id text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(player_id,claim_id));
ALTER TABLE battle_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE progression_claims ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER battle_actions_append_only BEFORE UPDATE OR DELETE ON battle_actions
FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER progression_claims_append_only BEFORE UPDATE OR DELETE ON progression_claims
FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
