CREATE TABLE "audit_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"actor_player_id" uuid,
	"action" text NOT NULL,
	"target_type" text,
	"target_id" text,
	"metadata" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "battle_turns" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"battle_id" uuid NOT NULL,
	"turn_no" integer NOT NULL,
	"actor" text NOT NULL,
	"action" text NOT NULL,
	"result" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "battle_turns_unique" UNIQUE("battle_id","turn_no","actor"),
	CONSTRAINT "battle_turns_actor_chk" CHECK ("battle_turns"."actor" in ('player','enemy'))
);
--> statement-breakpoint
CREATE TABLE "battles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"mode" text DEFAULT 'pve' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"player_id" uuid NOT NULL,
	"player_monster_id" uuid NOT NULL,
	"enemy_species_id" text NOT NULL,
	"enemy_level" integer NOT NULL,
	"seed" text NOT NULL,
	"state" jsonb NOT NULL,
	"turn_no" integer DEFAULT 0 NOT NULL,
	"reward_gold" integer DEFAULT 0 NOT NULL,
	"reward_xp" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"finished_at" timestamp with time zone,
	CONSTRAINT "battles_mode_chk" CHECK ("battles"."mode" in ('pve')),
	CONSTRAINT "battles_status_chk" CHECK ("battles"."status" in ('active','won','lost','abandoned'))
);
--> statement-breakpoint
CREATE TABLE "inventory_items" (
	"player_id" uuid NOT NULL,
	"item_id" text NOT NULL,
	"quantity" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "inventory_items_player_id_item_id_pk" PRIMARY KEY("player_id","item_id"),
	CONSTRAINT "inventory_qty_nonneg" CHECK ("inventory_items"."quantity" >= 0)
);
--> statement-breakpoint
CREATE TABLE "ledger_entries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"player_id" uuid NOT NULL,
	"currency" text NOT NULL,
	"delta" bigint NOT NULL,
	"balance_after" bigint NOT NULL,
	"reason" text NOT NULL,
	"ref_type" text,
	"ref_id" text,
	"idempotency_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ledger_entries_idempotency_key_unique" UNIQUE("idempotency_key"),
	CONSTRAINT "ledger_currency_chk" CHECK ("ledger_entries"."currency" in ('gold','crystals')),
	CONSTRAINT "ledger_delta_nonzero" CHECK ("ledger_entries"."delta" <> 0)
);
--> statement-breakpoint
CREATE TABLE "monster_species" (
	"id" text PRIMARY KEY NOT NULL,
	"line_id" text NOT NULL,
	"name" text NOT NULL,
	"element" text NOT NULL,
	"stage" integer NOT NULL,
	"evolves_to" text,
	"base_hp" integer NOT NULL,
	"base_atk" integer NOT NULL,
	"base_def" integer NOT NULL,
	"base_spd" integer NOT NULL,
	CONSTRAINT "species_stage_chk" CHECK ("monster_species"."stage" between 1 and 3),
	CONSTRAINT "species_element_chk" CHECK ("monster_species"."element" in ('fire','water','earth','lightning','light','dark'))
);
--> statement-breakpoint
CREATE TABLE "payment_orders" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"player_id" uuid NOT NULL,
	"telegram_user_id" bigint NOT NULL,
	"product_id" text NOT NULL,
	"payload" text NOT NULL,
	"amount" integer NOT NULL,
	"currency" text DEFAULT 'XTR' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"telegram_payment_charge_id" text,
	"provider_payment_charge_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"confirmed_at" timestamp with time zone,
	CONSTRAINT "payment_orders_payload_unique" UNIQUE("payload"),
	CONSTRAINT "payment_orders_telegram_payment_charge_id_unique" UNIQUE("telegram_payment_charge_id"),
	CONSTRAINT "payment_status_chk" CHECK ("payment_orders"."status" in ('pending','confirmed','failed','cancelled','refunded')),
	CONSTRAINT "payment_currency_chk" CHECK ("payment_orders"."currency" = 'XTR')
);
--> statement-breakpoint
CREATE TABLE "player_balances" (
	"player_id" uuid PRIMARY KEY NOT NULL,
	"gold" bigint DEFAULT 0 NOT NULL,
	"crystals" bigint DEFAULT 0 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "balances_gold_nonneg" CHECK ("player_balances"."gold" >= 0),
	CONSTRAINT "balances_crystals_nonneg" CHECK ("player_balances"."crystals" >= 0)
);
--> statement-breakpoint
CREATE TABLE "player_monsters" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"player_id" uuid NOT NULL,
	"species_id" text NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"xp" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "monster_level_chk" CHECK ("player_monsters"."level" between 1 and 100),
	CONSTRAINT "monster_xp_chk" CHECK ("player_monsters"."xp" >= 0)
);
--> statement-breakpoint
CREATE TABLE "players" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"display_name" text NOT NULL,
	"role" text DEFAULT 'player' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"banned_reason" text,
	"banned_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "players_role_chk" CHECK ("players"."role" in ('player','admin')),
	CONSTRAINT "players_status_chk" CHECK ("players"."status" in ('active','banned'))
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"stars_price" integer NOT NULL,
	"grants" jsonb NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	CONSTRAINT "products_price_chk" CHECK ("products"."stars_price" > 0)
);
--> statement-breakpoint
CREATE TABLE "rate_limits" (
	"key" text NOT NULL,
	"window_start" timestamp with time zone NOT NULL,
	"count" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "rate_limits_key_window_start_pk" PRIMARY KEY("key","window_start")
);
--> statement-breakpoint
CREATE TABLE "telegram_identities" (
	"telegram_user_id" bigint PRIMARY KEY NOT NULL,
	"player_id" uuid NOT NULL,
	"username" text,
	"first_name" text,
	"language_code" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_auth_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "telegram_identities_player_id_unique" UNIQUE("player_id")
);
--> statement-breakpoint
CREATE TABLE "telegram_updates" (
	"update_id" bigint PRIMARY KEY NOT NULL,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "battle_turns" ADD CONSTRAINT "battle_turns_battle_id_battles_id_fk" FOREIGN KEY ("battle_id") REFERENCES "public"."battles"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "battles" ADD CONSTRAINT "battles_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "battles" ADD CONSTRAINT "battles_player_monster_id_player_monsters_id_fk" FOREIGN KEY ("player_monster_id") REFERENCES "public"."player_monsters"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "battles" ADD CONSTRAINT "battles_enemy_species_id_monster_species_id_fk" FOREIGN KEY ("enemy_species_id") REFERENCES "public"."monster_species"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_items" ADD CONSTRAINT "inventory_items_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ledger_entries" ADD CONSTRAINT "ledger_entries_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payment_orders" ADD CONSTRAINT "payment_orders_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payment_orders" ADD CONSTRAINT "payment_orders_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "player_balances" ADD CONSTRAINT "player_balances_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "player_monsters" ADD CONSTRAINT "player_monsters_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "player_monsters" ADD CONSTRAINT "player_monsters_species_id_monster_species_id_fk" FOREIGN KEY ("species_id") REFERENCES "public"."monster_species"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "telegram_identities" ADD CONSTRAINT "telegram_identities_player_id_players_id_fk" FOREIGN KEY ("player_id") REFERENCES "public"."players"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "audit_logs_created_idx" ON "audit_logs" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "battles_player_idx" ON "battles" USING btree ("player_id","created_at");--> statement-breakpoint
CREATE INDEX "ledger_player_idx" ON "ledger_entries" USING btree ("player_id","created_at");--> statement-breakpoint
CREATE INDEX "payment_orders_player_idx" ON "payment_orders" USING btree ("player_id");--> statement-breakpoint
CREATE INDEX "player_monsters_player_idx" ON "player_monsters" USING btree ("player_id");