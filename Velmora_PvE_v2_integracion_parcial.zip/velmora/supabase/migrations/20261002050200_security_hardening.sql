-- Security hardening: RLS deny-by-default + append-only ledgers.
--
-- Model: browsers never query the database. Authentication is Telegram-based
-- (custom signed session), not Supabase Auth, so there is no auth.uid() to
-- bind per-row policies to. Therefore every table has RLS ENABLED with NO
-- policies for anon/authenticated => all direct access via the Supabase
-- REST/GraphQL API is denied. Only the backend's privileged connection
-- (service role / postgres owner, which bypasses RLS) can read/write.

-- 1. RLS on every game table -------------------------------------------------
ALTER TABLE public.players               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_identities   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.player_balances       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ledger_entries        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_items       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monster_species       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.player_monsters       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.battles               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.battle_turns          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_orders        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_limits           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_updates      ENABLE ROW LEVEL SECURITY;

-- 2. Revoke API roles (only exist on Supabase; guarded for plain Postgres) ----
DO $$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['anon', 'authenticated'] LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('REVOKE ALL ON ALL TABLES IN SCHEMA public FROM %I', r);
      EXECUTE format('REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM %I', r);
      EXECUTE format('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM %I', r);
      EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM %I', r);
    END IF;
  END LOOP;
END $$;

-- 3. Append-only tables ------------------------------------------------------
CREATE OR REPLACE FUNCTION public.forbid_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% on % is forbidden: table is append-only', TG_OP, TG_TABLE_NAME
    USING ERRCODE = 'restrict_violation';
END $$;

DROP TRIGGER IF EXISTS ledger_entries_append_only ON public.ledger_entries;
CREATE TRIGGER ledger_entries_append_only
  BEFORE UPDATE OR DELETE ON public.ledger_entries
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

DROP TRIGGER IF EXISTS audit_logs_append_only ON public.audit_logs;
CREATE TRIGGER audit_logs_append_only
  BEFORE UPDATE OR DELETE ON public.audit_logs
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

DROP TRIGGER IF EXISTS battle_turns_append_only ON public.battle_turns;
CREATE TRIGGER battle_turns_append_only
  BEFORE UPDATE OR DELETE ON public.battle_turns
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

-- 4. A confirmed payment can never go back to another state except refund ----
CREATE OR REPLACE FUNCTION public.guard_payment_status() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status = 'confirmed' AND NEW.status NOT IN ('confirmed', 'refunded') THEN
    RAISE EXCEPTION 'payment % is confirmed; illegal transition to %', OLD.id, NEW.status
      USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.status = 'confirmed' AND NEW.telegram_payment_charge_id IS DISTINCT FROM OLD.telegram_payment_charge_id THEN
    RAISE EXCEPTION 'payment % charge id is immutable once confirmed', OLD.id
      USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS payment_orders_guard ON public.payment_orders;
CREATE TRIGGER payment_orders_guard
  BEFORE UPDATE ON public.payment_orders
  FOR EACH ROW EXECUTE FUNCTION public.guard_payment_status();
