# Assets de la entrega PvE v2

Se incluyen seis PNG de 192×64, con tres celdas de 64×64 por línea elemental.
Son placeholders originales generados por dibujo procedural con Pillow,
no las ilustraciones finales ausentes en el ZIP. No implican que el arte anterior
haya sido recuperado. La UI utiliza cada celda con un fallback textual al fallar.

Los efectos `hit.wav`, `victory.wav` y `evolve.wav` son síntesis sinusoidal original.
La procedencia y licencia CC0 se registran en `public/assets/audio/audio_manifest.json`.
El sonido se activa voluntariamente y puede bloquearlo el navegador.

Hay animación CSS de impacto, secuenciación de eventos y movimiento reducido.
No hay sprites de ataque/derrota/evolución por fotogramas, música ni arte final.
La auditoría verifica archivos esperados, dimensiones, alfa y límite de colores.
