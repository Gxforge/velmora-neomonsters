# Security

## Secrets
- All secrets come from environment variables (see `.env.example`). Nothing secret is in the repo; `npm run audit:forbidden` (also in CI) scans for token patterns.
- `TELEGRAM_BOT_TOKEN`, `SESSION_SECRET`, `TELEGRAM_WEBHOOK_SECRET`, `DATABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` are server-only. Only `NEXT_PUBLIC_*` variables reach the browser; none is used.
- **Credentials were pasted in a chat during setup. They are considered exposed and MUST be rotated** (GitHub, Vercel, Supabase access token, Telegram bot token via BotFather `/revoke`, Supabase DB password/service key). Credentials found in the legacy project must not be reused.

## Controls
| Control | Status |
|---|---|
| initData HMAC verification + max age 1h | IMPLEMENTED |
| Signed session tokens, 12h TTL, ban checked on every request | IMPLEMENTED |
| Server-side validation (zod) of every input, body size cap | IMPLEMENTED |
| Ownership checks (monsters, battles) | IMPLEMENTED |
| Idempotent, row-locked ledger; append-only ledger/audit/turn tables | IMPLEMENTED |
| Payment idempotency + replay protection (payload, charge id, update_id) | IMPLEMENTED |
| Webhook secret-token check (constant time) | IMPLEMENTED |
| Rate limiting (login, battles, evolve, invoices) | IMPLEMENTED (fixed window, DB) |
| Admin authorization in backend (DB role AND `ADMIN_TELEGRAM_IDS`) | IMPLEMENTED |
| Audit logs for registrations, battles, evolutions, payments, admin actions | IMPLEMENTED |
| Impossible-action detection | PARTIAL (logs skill-on-cooldown attempts) |
| RLS deny-by-default | IMPLEMENTED (see DATABASE.md) |
| Security headers / CSP | TODO |
| External error tracking, alerting | NOT IMPLEMENTED |
| Automated dependency audit | TODO (`npm audit` reports known issues in dev tooling) |
| Penetration test / third-party review | NOT IMPLEMENTED |

## Reporting
Open a private issue with the repository owner.
