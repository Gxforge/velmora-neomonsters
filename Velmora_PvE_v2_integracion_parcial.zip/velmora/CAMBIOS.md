# Archivos modificados

- `.github/workflows/ci.yml`
- `ASSETS.md`
- `README.md`
- `public/assets/audio/audio_manifest.json`
- `public/assets/evolution/manifest.json`
- `scripts/assets/audit-palette.ts`
- `src/app/admin/page.tsx`
- `src/app/api/battles/[id]/action/route.ts`
- `src/app/api/battles/route.ts`
- `src/app/globals.css`
- `src/app/layout.tsx`
- `src/app/page.tsx`
- `src/db/schema.ts`
- `src/lib/game/combat.ts`
- `src/lib/game/progression.ts`
- `src/server/admin.ts`
- `src/server/battles.ts`
- `src/server/monsters.ts`
- `src/server/payments.ts`
- `tests/integration/flows.test.ts`

# Archivos nuevos

- `INTEGRACION.md`
- `public/assets/audio/evolve.wav`
- `public/assets/audio/hit.wav`
- `public/assets/audio/victory.wav`
- `public/assets/evolution/dark.png`
- `public/assets/evolution/earth.png`
- `public/assets/evolution/fire.png`
- `public/assets/evolution/light.png`
- `public/assets/evolution/lightning.png`
- `public/assets/evolution/water.png`
- `scripts/bootstrap.sh`
- `src/app/api/adventure/route.ts`
- `src/app/api/battles/[id]/abandon/route.ts`
- `src/app/api/battles/[id]/capture/route.ts`
- `src/app/api/payments/history/route.ts`
- `src/app/api/quests/claim/route.ts`
- `src/components/AdventurePanel.tsx`
- `src/components/Collection.tsx`
- `src/components/Creature.tsx`
- `src/lib/client/feedback.ts`
- `src/lib/game/adventure.ts`
- `src/lib/game/skills.ts`
- `src/server/adventure.ts`
- `supabase/migrations/20261002050300_pve_v2.sql`
- `tests/unit/pve-v2.test.ts`

Este listado precede a la generación de los informes finales y del ZIP.
