import { eq } from "drizzle-orm";
import type { Tx } from "@/db";
import { ledgerEntries, playerBalances } from "@/db/schema";
import { HttpError } from "./http";

export type Currency = "gold" | "crystals";

/**
 * The ONLY way balances change. Runs inside the caller's transaction:
 *  - locks the player's balance row (serialises concurrent operations)
 *  - idempotent: the same idempotencyKey is applied at most once
 *  - refuses to go negative (also enforced by a DB CHECK)
 *  - appends an immutable ledger entry (DB trigger forbids update/delete)
 * Clients never state how much they received; the backend decides.
 */
export async function applyLedger(
  tx: Tx,
  p: {
    playerId: string;
    currency: Currency;
    delta: number;
    reason: string;
    refType?: string;
    refId?: string;
    idempotencyKey: string;
  },
): Promise<{ applied: boolean; balanceAfter: number }> {
  if (!Number.isSafeInteger(p.delta) || p.delta === 0) throw new Error("invalid ledger delta");

  await tx.insert(playerBalances).values({ playerId: p.playerId }).onConflictDoNothing();
  const [bal] = await tx
    .select()
    .from(playerBalances)
    .where(eq(playerBalances.playerId, p.playerId))
    .for("update");

  const [existing] = await tx
    .select()
    .from(ledgerEntries)
    .where(eq(ledgerEntries.idempotencyKey, p.idempotencyKey));
  if (existing) {
    if (existing.playerId !== p.playerId || existing.currency !== p.currency || existing.delta !== p.delta) {
      throw new Error("idempotency key reused with different parameters");
    }
    return { applied: false, balanceAfter: existing.balanceAfter };
  }

  const next = (p.currency === "gold" ? bal.gold : bal.crystals) + p.delta;
  if (next < 0) throw new HttpError(402, "insufficient_funds");

  await tx
    .update(playerBalances)
    .set(p.currency === "gold" ? { gold: next, updatedAt: new Date() } : { crystals: next, updatedAt: new Date() })
    .where(eq(playerBalances.playerId, p.playerId));

  await tx.insert(ledgerEntries).values({
    playerId: p.playerId,
    currency: p.currency,
    delta: p.delta,
    balanceAfter: next,
    reason: p.reason,
    refType: p.refType,
    refId: p.refId,
    idempotencyKey: p.idempotencyKey,
  });
  return { applied: true, balanceAfter: next };
}
