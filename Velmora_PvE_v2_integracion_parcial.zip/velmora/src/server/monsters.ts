import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { playerMonsters, players } from "@/db/schema";
import { SPECIES_BY_ID, STARTER_GOLD, STARTER_LINES, type Element } from "@/lib/game/catalog";
import { checkEvolution, EVOLUTION_RULES, statAt, xpToNext } from "@/lib/game/progression";
import { audit } from "./audit";
import { applyLedger } from "./economy";
import { HttpError } from "./http";

export function monsterView(m: typeof playerMonsters.$inferSelect) {
  const sp = SPECIES_BY_ID.get(m.speciesId)!;
  return {
    id: m.id,
    speciesId: sp.id,
    name: sp.name,
    element: sp.element,
    stage: sp.stage,
    level: m.level,
    xp: m.xp,
    xpToNext: xpToNext(m.level),
    stats: {
      hp: statAt(sp.baseHp, m.level),
      atk: statAt(sp.baseAtk, m.level),
      def: statAt(sp.baseDef, m.level),
      spd: statAt(sp.baseSpd, m.level),
    },
    canEvolve: checkEvolution(sp.stage, m.level).ok,
    evolution: sp.stage < 3 ? { ...EVOLUTION_RULES[sp.stage as 1 | 2],
      target: SPECIES_BY_ID.get(sp.evolvesTo!) } : null,
  };
}

/** One-time starter selection. The server validates the line and grants the monster. */
export async function chooseStarter(playerId: string, lineId: string) {
  if (!STARTER_LINES.includes(lineId as Element)) throw new HttpError(400, "invalid_starter");
  return db.transaction(async (tx) => {
    // serialise concurrent requests for the same player
    await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
    const owned = await tx.select({ id: playerMonsters.id }).from(playerMonsters).where(eq(playerMonsters.playerId, playerId)).limit(1);
    if (owned.length) throw new HttpError(409, "starter_already_chosen");
    const [m] = await tx.insert(playerMonsters).values({ playerId, speciesId: `${lineId}_1` }).returning();
    await applyLedger(tx, {
      playerId, currency: "gold", delta: STARTER_GOLD, reason: "starter_bonus",
      refType: "player", refId: playerId, idempotencyKey: `starter:${playerId}`,
    });
    await audit(tx, { actor: playerId, action: "monster.starter", targetType: "monster", targetId: m.id, metadata: { lineId } });
    return monsterView(m);
  });
}

/** Evolution: ownership, level and cost are all checked and charged server-side. */
export async function evolveMonster(playerId: string, monsterId: string) {
  return db.transaction(async (tx) => {
    await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
    const [m] = await tx
      .select()
      .from(playerMonsters)
      .where(and(eq(playerMonsters.id, monsterId), eq(playerMonsters.playerId, playerId)))
      .for("update");
    if (!m) throw new HttpError(404, "monster_not_found");
    const sp = SPECIES_BY_ID.get(m.speciesId)!;
    const check = checkEvolution(sp.stage, m.level);
    if (!check.ok) throw new HttpError(409, check.reason);
    const target = sp.evolvesTo!;

    if (check.cost.gold > 0) {
      await applyLedger(tx, {
        playerId, currency: "gold", delta: -check.cost.gold, reason: "evolution",
        refType: "monster", refId: m.id, idempotencyKey: `evolve:${m.id}:${target}:gold`,
      });
    }
    if (check.cost.crystals > 0) {
      await applyLedger(tx, {
        playerId, currency: "crystals", delta: -check.cost.crystals, reason: "evolution",
        refType: "monster", refId: m.id, idempotencyKey: `evolve:${m.id}:${target}:crystals`,
      });
    }
    const [updated] = await tx.update(playerMonsters).set({ speciesId: target }).where(eq(playerMonsters.id, m.id)).returning();
    await audit(tx, { actor: playerId, action: "monster.evolved", targetType: "monster", targetId: m.id, metadata: { from: sp.id, to: target } });
    return monsterView(updated);
  });
}
