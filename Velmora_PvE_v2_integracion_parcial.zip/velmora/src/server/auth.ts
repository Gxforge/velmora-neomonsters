import { eq } from "drizzle-orm";
import { db } from "@/db";
import { playerBalances, players, telegramIdentities } from "@/db/schema";
import { signSession, verifySession } from "@/lib/session";
import { validateInitData, InitDataError } from "@/lib/telegram/initData";
import { audit } from "./audit";
import { ensureCatalog } from "./catalog-sync";
import { adminTelegramIds, botToken, sessionSecret } from "./env";
import { HttpError } from "./http";
import { rateLimit } from "./rateLimit";
import { log } from "./logger";

export type PlayerRow = typeof players.$inferSelect;

const cleanName = (s: string) => s.replace(/[\u0000-\u001f<>]/g, "").trim().slice(0, 32) || "Trainer";

/**
 * Telegram login: validates initData server-side (HMAC with the bot token),
 * links the Telegram identity to a game account (creating it on first use)
 * and issues a signed session. Banned players cannot log in.
 */
export async function loginWithTelegram(initData: string) {
  let v;
  try {
    v = validateInitData(initData, botToken());
  } catch (e) {
    if (e instanceof InitDataError) {
      log.warn("auth.rejected", { code: e.code });
      throw new HttpError(401, "invalid_init_data");
    }
    throw e;
  }
  await rateLimit(`login:${v.user.id}`, 20, 60);
  await ensureCatalog();

  const isAdmin = adminTelegramIds().includes(v.user.id);
  const player = await db.transaction(async (tx) => {
    const [identity] = await tx
      .select()
      .from(telegramIdentities)
      .where(eq(telegramIdentities.telegramUserId, v.user.id));

    if (identity) {
      await tx
        .update(telegramIdentities)
        .set({
          username: v.user.username ?? null,
          firstName: v.user.first_name ?? null,
          languageCode: v.user.language_code ?? null,
          lastAuthAt: new Date(),
        })
        .where(eq(telegramIdentities.telegramUserId, v.user.id));
      const [p] = await tx
        .update(players)
        .set({ lastSeenAt: new Date(), role: isAdmin ? "admin" : "player" })
        .where(eq(players.id, identity.playerId))
        .returning();
      return p;
    }

    const [p] = await tx
      .insert(players)
      .values({
        displayName: cleanName(v.user.first_name ?? v.user.username ?? "Trainer"),
        role: isAdmin ? "admin" : "player",
      })
      .returning();
    await tx.insert(telegramIdentities).values({
      telegramUserId: v.user.id,
      playerId: p.id,
      username: v.user.username ?? null,
      firstName: v.user.first_name ?? null,
      languageCode: v.user.language_code ?? null,
    });
    await tx.insert(playerBalances).values({ playerId: p.id });
    await audit(tx, { actor: p.id, action: "player.registered", targetType: "player", targetId: p.id });
    return p;
  });

  if (player.status === "banned") throw new HttpError(403, "banned");
  const token = signSession({ pid: player.id, tg: v.user.id }, sessionSecret());
  return { token, player: { id: player.id, displayName: player.displayName, role: player.role } };
}

function bearer(req: Request): string {
  const h = req.headers.get("authorization") ?? "";
  if (!h.startsWith("Bearer ")) throw new HttpError(401, "unauthenticated");
  return h.slice(7).trim();
}

/** Resolves the authenticated, non-banned player. Status is re-read from the DB each call. */
export async function requirePlayer(req: Request): Promise<PlayerRow & { telegramUserId: number }> {
  const s = verifySession(bearer(req), sessionSecret());
  if (!s) throw new HttpError(401, "invalid_session");
  const [p] = await db.select().from(players).where(eq(players.id, s.pid));
  if (!p) throw new HttpError(401, "invalid_session");
  if (p.status === "banned") throw new HttpError(403, "banned");
  return { ...p, telegramUserId: s.tg };
}

/**
 * Admin authorization is enforced on the server for every privileged call:
 * DB role must be 'admin' AND the Telegram id must still be in ADMIN_TELEGRAM_IDS
 * (so revoking an admin only needs an env change; no stale sessions).
 */
export async function requireAdmin(req: Request) {
  const p = await requirePlayer(req);
  if (p.role !== "admin" || !adminTelegramIds().includes(p.telegramUserId)) {
    log.warn("admin.denied", { playerId: p.id });
    throw new HttpError(403, "forbidden");
  }
  return p;
}
