import { sql } from "drizzle-orm";
import { db } from "@/db";
import { HttpError } from "./http";

/** Fixed-window rate limiter backed by Postgres (works across serverless instances). */
export async function rateLimit(key: string, limit: number, windowSec: number): Promise<void> {
  const windowMs = windowSec * 1000;
  const windowStart = new Date(Math.floor(Date.now() / windowMs) * windowMs).toISOString();
  const res = await db.execute<{ count: number }>(sql`
    insert into rate_limits (key, window_start, count)
    values (${key}, ${windowStart}::timestamptz, 1)
    on conflict (key, window_start) do update set count = rate_limits.count + 1
    returning count`);
  const count = Number(res.rows[0]?.count ?? 0);
  if (Math.random() < 0.01) {
    void db.execute(sql`delete from rate_limits where window_start < now() - interval '1 day'`).catch(() => {});
  }
  if (count > limit) throw new HttpError(429, "rate_limited");
}
