/**
 * Telegram Stars (currency XTR) payments.
 *
 * Flow (goods are NEVER delivered because an invoice was created):
 *  1. POST invoice  -> payment_orders row (pending) + createInvoiceLink
 *  2. Telegram sends pre_checkout_query -> we validate the order and answer ok/not ok
 *  3. Telegram sends message.successful_payment -> only now do we confirm the
 *     order and credit goods, atomically and idempotently (unique payload,
 *     unique telegram_payment_charge_id, ledger idempotency key payment:<orderId>).
 * Replayed webhooks (same update_id / same charge id) never deliver twice.
 */
import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { paymentOrders, players, products } from "@/db/schema";
import { PRODUCT_BY_ID } from "@/lib/game/catalog";
import { audit } from "./audit";
import { ensureCatalog } from "./catalog-sync";
import { applyLedger } from "./economy";
import { botToken } from "./env";
import { HttpError } from "./http";
import { log } from "./logger";
import { rateLimit } from "./rateLimit";

export async function tgCall<T>(method: string, body: Record<string, unknown>): Promise<T> {
  const res = await fetch(`https://api.telegram.org/bot${botToken()}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = (await res.json()) as { ok: boolean; result?: T; description?: string };
  if (!data.ok) throw new Error(`telegram ${method} failed: ${data.description ?? res.status}`);
  return data.result as T;
}

export async function createStarsInvoice(player: { id: string; telegramUserId: number }, productId: string) {
  await ensureCatalog();
  await rateLimit(`invoice:${player.id}`, 10, 3600);
  const def = PRODUCT_BY_ID.get(productId);
  if (!def) throw new HttpError(404, "product_not_found");
  const [prod] = await db.select().from(products).where(eq(products.id, productId));
  if (!prod || !prod.active) throw new HttpError(404, "product_not_found");

  const payload = randomUUID();
  const [order] = await db
    .insert(paymentOrders)
    .values({
      playerId: player.id, telegramUserId: player.telegramUserId, productId,
      payload, amount: prod.starsPrice, currency: "XTR",
      productSnapshot: { name: prod.name, starsPrice: prod.starsPrice, grants: prod.grants },
    })
    .returning();
  try {
    const link = await tgCall<string>("createInvoiceLink", {
      title: prod.name,
      description: prod.description,
      payload,
      provider_token: "", // must be empty for Telegram Stars
      currency: "XTR",
      prices: [{ label: prod.name, amount: prod.starsPrice }],
    });
    await audit(db, { actor: player.id, action: "payment.invoice_created", targetType: "payment_order", targetId: order.id, metadata: { productId, amount: prod.starsPrice } });
    return { orderId: order.id, invoiceLink: link };
  } catch (e) {
    await db.update(paymentOrders).set({ status: "failed" }).where(eq(paymentOrders.id, order.id));
    log.error("payment.invoice_failed", { orderId: order.id, message: (e as Error).message });
    throw new HttpError(502, "invoice_unavailable");
  }
}

export type PreCheckout = { id: string; from: { id: number }; currency: string; total_amount: number; invoice_payload: string };

/** Validates a pre_checkout_query. Returns an error message to reject, or null to approve. */
export async function validatePreCheckout(q: PreCheckout): Promise<string | null> {
  const [order] = await db.select().from(paymentOrders).where(eq(paymentOrders.payload, q.invoice_payload));
  if (!order) return "Unknown order";
  if (order.status !== "pending") return "Order is not payable";
  if (Date.now() - order.createdAt.getTime() > 24 * 3600_000) return "Order expired; create a new invoice";
  if (order.telegramUserId !== q.from.id) return "Order belongs to another user";
  if (order.currency !== q.currency || order.amount !== q.total_amount) return "Price mismatch";
  const [p] = await db.select().from(players).where(eq(players.id, order.playerId));
  if (!p || p.status === "banned") return "Account unavailable";
  return null;
}

export type SuccessfulPayment = {
  telegramUserId: number;
  payload: string;
  totalAmount: number;
  currency: string;
  chargeId: string;
  providerChargeId?: string;
};

export type ConfirmResult = "confirmed" | "duplicate" | "unknown_order" | "rejected";

/** Confirms a REAL payment reported by Telegram and delivers goods exactly once. */
export async function confirmStarsPayment(sp: SuccessfulPayment): Promise<ConfirmResult> {
  return db.transaction(async (tx) => {
    const [order] = await tx.select().from(paymentOrders).where(eq(paymentOrders.payload, sp.payload)).for("update");
    if (!order) {
      log.error("payment.unknown_order", { chargeId: sp.chargeId, telegramUserId: sp.telegramUserId });
      await audit(tx, { action: "payment.unknown_order", metadata: { chargeId: sp.chargeId, telegramUserId: sp.telegramUserId, amount: sp.totalAmount } });
      return "unknown_order";
    }
    if (order.status === "confirmed") {
      if (order.telegramPaymentChargeId !== sp.chargeId) {
        log.error("payment.charge_conflict", { orderId: order.id });
        await audit(tx, { action: "payment.charge_conflict", targetType: "payment_order", targetId: order.id, metadata: { chargeId: sp.chargeId } });
      }
      return "duplicate";
    }
    if (
      order.status !== "pending" ||
      order.telegramUserId !== sp.telegramUserId ||
      order.amount !== sp.totalAmount ||
      order.currency !== sp.currency
    ) {
      log.error("payment.rejected", { orderId: order.id, status: order.status });
      await audit(tx, { actor: order.playerId, action: "payment.rejected_needs_review", targetType: "payment_order", targetId: order.id, metadata: { status: order.status, chargeId: sp.chargeId, amount: sp.totalAmount } });
      return "rejected";
    }

    await tx
      .update(paymentOrders)
      .set({ status: "confirmed", telegramPaymentChargeId: sp.chargeId, providerPaymentChargeId: sp.providerChargeId, confirmedAt: new Date() })
      .where(eq(paymentOrders.id, order.id));

    const grants = (order.productSnapshot as { grants: { gold?: number; crystals?: number } }).grants;
    for (const currency of ["gold", "crystals"] as const) {
      const amount = grants[currency];
      if (amount) {
        await applyLedger(tx, {
          playerId: order.playerId, currency, delta: amount, reason: "stars_purchase",
          refType: "payment_order", refId: order.id, idempotencyKey: `payment:${order.id}:${currency}`,
        });
      }
    }
    await audit(tx, { actor: order.playerId, action: "payment.confirmed", targetType: "payment_order", targetId: order.id, metadata: { productId: order.productId, amount: order.amount } });
    log.info("payment.confirmed", { orderId: order.id, productId: order.productId });
    return "confirmed";
  });
}
