import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { battles, inventoryItems, playerBalances, playerMonsters, products } from "@/db/schema";
import { monsterView } from "./monsters";
import type { PlayerRow } from "./auth";

export async function getProfile(player: PlayerRow) {
  const [bal] = await db.select().from(playerBalances).where(eq(playerBalances.playerId, player.id));
  const monsters = await db.select().from(playerMonsters).where(eq(playerMonsters.playerId, player.id)).orderBy(desc(playerMonsters.level));
  const items = await db.select().from(inventoryItems).where(eq(inventoryItems.playerId, player.id));
  const [active] = await db.select({ id: battles.id }).from(battles).where(and(eq(battles.playerId, player.id), eq(battles.status, "active")));
  return {
    player: { id: player.id, displayName: player.displayName, role: player.role },
    balances: { gold: bal?.gold ?? 0, crystals: bal?.crystals ?? 0 },
    monsters: monsters.map(monsterView),
    inventory: items.map((i) => ({ itemId: i.itemId, quantity: i.quantity })),
    activeBattleId: active?.id ?? null,
    needsStarter: monsters.length === 0,
  };
}

export const listProducts = () =>
  db.select({ id: products.id, name: products.name, description: products.description, starsPrice: products.starsPrice }).from(products).where(eq(products.active, true));
