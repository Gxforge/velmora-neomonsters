import { sql } from "drizzle-orm";
import { db } from "@/db";
import { monsterSpecies, products } from "@/db/schema";
import { PRODUCTS, SPECIES } from "@/lib/game/catalog";

let done: Promise<void> | null = null;

/** Upserts the static catalog (species, products) into the DB once per instance. */
export function ensureCatalog(): Promise<void> {
  done ??= (async () => {
    await db
      .insert(monsterSpecies)
      .values(
        SPECIES.map((s) => ({
          id: s.id, lineId: s.lineId, name: s.name, element: s.element, stage: s.stage,
          evolvesTo: s.evolvesTo, baseHp: s.baseHp, baseAtk: s.baseAtk, baseDef: s.baseDef, baseSpd: s.baseSpd,
        })),
      )
      .onConflictDoUpdate({
        target: monsterSpecies.id,
        set: {
          name: sql`excluded.name`, baseHp: sql`excluded.base_hp`, baseAtk: sql`excluded.base_atk`,
          baseDef: sql`excluded.base_def`, baseSpd: sql`excluded.base_spd`, evolvesTo: sql`excluded.evolves_to`,
        },
      });
    await db
      .insert(products)
      .values(PRODUCTS.map((p) => ({ id: p.id, name: p.name, description: p.description, starsPrice: p.starsPrice, grants: p.grants })))
      .onConflictDoUpdate({
        target: products.id,
        set: {
          name: sql`excluded.name`, description: sql`excluded.description`,
          starsPrice: sql`excluded.stars_price`, grants: sql`excluded.grants`,
        },
      });
  })().catch((e) => {
    done = null;
    throw e;
  });
  return done;
}
