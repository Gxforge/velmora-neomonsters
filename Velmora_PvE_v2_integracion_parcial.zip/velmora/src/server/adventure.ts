import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { battles, playerMonsters, players, progressionClaims, paymentOrders } from "@/db/schema";
import { SPECIES } from "@/lib/game/catalog";
import { REGIONS, QUESTS, captureChance } from "@/lib/game/adventure";
import { rngFor } from "@/lib/game/rng";
import { applyLedger } from "./economy";
import { HttpError } from "./http";
import { audit } from "./audit";

export async function adventureView(playerId: string) {
 const monsters = await db.select().from(playerMonsters).where(eq(playerMonsters.playerId, playerId));
 const history = await db.select().from(battles).where(eq(battles.playerId, playerId)).orderBy(desc(battles.createdAt));
 const claims = await db.select().from(progressionClaims).where(eq(progressionClaims.playerId, playerId));
 const claimed = new Set(claims.map(c => c.claimId));
 const owned = new Set(monsters.map(m => m.speciesId));
 const seen = new Set([...owned, ...history.map(b => b.enemySpeciesId)]);
 const metrics = { wins: history.filter(b => b.status === "won").length, species: owned.size,
   evolved: monsters.filter(m => !m.speciesId.endsWith("_1")).length };
 return {
   tutorial: { starter: monsters.length > 0, battle: metrics.wins > 0,
     capture: history.some(b => (b.captureResult as { success?: boolean } | null)?.success) },
   regions: REGIONS.map((r, i) => ({ ...r, unlocked: i === 0 || claimed.has(`boss:${REGIONS[i-1].id}`),
     completed: claimed.has(`boss:${r.id}`) })),
   bestiary: SPECIES.map(s => ({ ...s, owned: owned.has(s.id), discovered: seen.has(s.id),
     location: REGIONS.find(r => r.elements.includes(s.element))?.name })),
   quests: QUESTS.map(q => ({ ...q, progress: metrics[q.metric], claimed: claimed.has(`quest:${q.id}`) })),
   history: history.slice(0, 30).map(b => ({ id: b.id, status: b.status, turn: b.turnNo, regionId: b.regionId, createdAt: b.createdAt })),
 };
}

/** One attempt per victorious wild encounter. Retry returns the stored result. */
export async function captureMonster(playerId: string, battleId: string) {
 return db.transaction(async tx => {
   await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
   const [b] = await tx.select().from(battles).where(and(eq(battles.id, battleId), eq(battles.playerId, playerId))).for("update");
   if (!b) throw new HttpError(404, "battle_not_found");
   if (b.captureResult) return b.captureResult;
   if (b.status !== "won" || b.boss) throw new HttpError(409, "not_capturable");
   const owned = await tx.select({ id: playerMonsters.id }).from(playerMonsters).where(eq(playerMonsters.playerId, playerId));
   const chance = captureChance(owned.length);
   const success = rngFor(b.seed, "capture")() < chance;
   let monsterId: string | null = null;
   if (success) {
     const [m] = await tx.insert(playerMonsters).values({ playerId, speciesId: b.enemySpeciesId, level: b.enemyLevel }).returning();
     monsterId = m.id;
   }
   const result = { success, chance, monsterId, speciesId: b.enemySpeciesId };
   await tx.update(battles).set({ captureResult: result }).where(eq(battles.id, b.id));
   await audit(tx, { actor: playerId, action: "monster.capture", targetType: "battle", targetId: b.id, metadata: result });
   return result;
 });
}

export async function claimQuest(playerId: string, questId: string) {
 const q = QUESTS.find(q => q.id === questId);
 if (!q) throw new HttpError(404, "quest_not_found");
 return db.transaction(async tx => {
   await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
   const monsters = await tx.select().from(playerMonsters).where(eq(playerMonsters.playerId, playerId));
   const wins = await tx.select({ id: battles.id }).from(battles).where(and(eq(battles.playerId, playerId), eq(battles.status, "won")));
   const metrics = { wins: wins.length, species: new Set(monsters.map(m => m.speciesId)).size,
     evolved: monsters.filter(m => !m.speciesId.endsWith("_1")).length };
   if (metrics[q.metric] < q.goal) throw new HttpError(409, "quest_incomplete");
   const [claim] = await tx.insert(progressionClaims).values({ playerId, claimId: `quest:${q.id}` }).onConflictDoNothing().returning();
   if (!claim) return { claimed: true, duplicate: true };
   for (const currency of ["gold", "crystals"] as const) {
     await applyLedger(tx, { playerId, currency, delta: q[currency], reason: "quest_reward", idempotencyKey: `quest:${playerId}:${q.id}:${currency}` });
   }
   await audit(tx, { actor: playerId, action: "quest.claimed", targetId: q.id });
   return { claimed: true, duplicate: false };
 });
}

export async function abandonBattle(playerId: string, battleId: string) {
 return db.transaction(async tx => {
   await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
   const [b] = await tx.select().from(battles).where(and(eq(battles.id, battleId), eq(battles.playerId, playerId))).for("update");
   if (!b) throw new HttpError(404, "battle_not_found");
   if (b.status === "active") await tx.update(battles).set({ status: "abandoned", finishedAt: new Date() }).where(eq(battles.id, b.id));
   return { status: b.status === "active" ? "abandoned" : b.status };
 });
}
export async function paymentHistory(playerId: string) {
 return db.select({ id: paymentOrders.id, productId: paymentOrders.productId, amount: paymentOrders.amount,
   status: paymentOrders.status, createdAt: paymentOrders.createdAt, confirmedAt: paymentOrders.confirmedAt })
   .from(paymentOrders).where(eq(paymentOrders.playerId, playerId)).orderBy(desc(paymentOrders.createdAt)).limit(50);
}
