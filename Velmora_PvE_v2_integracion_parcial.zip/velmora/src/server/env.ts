/** Server-only configuration. Never import this from client components. */
export function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required environment variable ${name}`);
  return v;
}

export const botToken = () => requireEnv("TELEGRAM_BOT_TOKEN");
export const sessionSecret = () => requireEnv("SESSION_SECRET");
export const webhookSecret = () => requireEnv("TELEGRAM_WEBHOOK_SECRET");

/** Telegram user ids allowed to hold the admin role (comma separated). */
export function adminTelegramIds(): number[] {
  return (process.env.ADMIN_TELEGRAM_IDS ?? "")
    .split(",")
    .map((s) => Number(s.trim()))
    .filter((n) => Number.isSafeInteger(n) && n > 0);
}
