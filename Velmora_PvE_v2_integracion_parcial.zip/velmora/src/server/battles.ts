import { randomUUID } from "node:crypto";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { battles, battleTurns, playerMonsters, players, battleActions, progressionClaims } from "@/db/schema";
import { SPECIES, SPECIES_BY_ID } from "@/lib/game/catalog";
import { CombatError, enemyIntent, newBattle, resolveTurn, type Action, type BattleState, type TurnEvent } from "@/lib/game/combat";
import { applyXp, pickEnemy, statAt, winRewards } from "@/lib/game/progression";
import { REGIONS, type Difficulty } from "@/lib/game/adventure";
import { rngFor } from "@/lib/game/rng";
import { audit } from "./audit";
import { applyLedger } from "./economy";
import { HttpError } from "./http";
import { log } from "./logger";

type BattleRow = typeof battles.$inferSelect;

export function battleView(b: BattleRow, events: TurnEvent[] = []) {
  const s = b.state as BattleState;
  return {
    id: b.id,
    mode: b.mode,
    status: b.status,
    turn: s.turn,
    winner: s.winner,
    player: s.player,
    enemy: s.enemy,
    events,
    regionId: b.regionId, boss: b.boss, difficulty: b.difficulty,
    captureResult: b.captureResult,
    captureAvailable: b.status === "won" && !b.boss && !b.captureResult,
    rulesVersion: b.rulesVersion,
    enemyIntent: s.winner ? null : enemyIntent(s),
    rewards: b.status === "won" ? { gold: b.rewardGold, xp: b.rewardXp, crystals: 1 } : null,
  };
}

/** Starts (or resumes, after a disconnect) a server-authoritative PvE battle. */
export async function startPve(playerId: string, monsterId: string,
  options: { regionId?: string; boss?: boolean; difficulty?: Difficulty } = {}) {
  return db.transaction(async (tx) => {
    await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
    const [m] = await tx
      .select()
      .from(playerMonsters)
      .where(and(eq(playerMonsters.id, monsterId), eq(playerMonsters.playerId, playerId)))
      .for("update");
    if (!m) throw new HttpError(404, "monster_not_found");

    const [active] = await tx
      .select()
      .from(battles)
      .where(and(eq(battles.playerId, playerId), eq(battles.status, "active")));
    if (active) return { ...battleView(active), resumed: true };

    const seed = randomUUID();
    const sp = SPECIES_BY_ID.get(m.speciesId)!;
    const region = options.regionId ? REGIONS.find(r => r.id === options.regionId) : undefined;
    if (options.regionId && !region) throw new HttpError(400, "invalid_region");
    if (region) {
      const idx = REGIONS.indexOf(region);
      if (m.level < region.minLevel) throw new HttpError(409, "region_level_required");
      if (idx > 0) {
        const [claim] = await tx.select().from(progressionClaims).where(and(
          eq(progressionClaims.playerId, playerId), eq(progressionClaims.claimId, `boss:${REGIONS[idx - 1].id}`)));
        if (!claim) throw new HttpError(409, "region_locked");
      }
    }
    const difficulty = options.difficulty ?? "normal";
    const enemy = pickEnemy(seed, m.level);
    // Wild enemies never auto-evolve beyond the player's current stage.
    const pool = SPECIES.filter(s => s.stage <= sp.stage && (!region || region.elements.includes(s.element)));
    enemy.species = pool[Math.floor(rngFor(seed, "region")() * pool.length)];
    if (region && options.boss) enemy.species = SPECIES_BY_ID.get(region.boss)!;
    enemy.level = Math.min(100, enemy.level + (difficulty === "hard" ? 2 : difficulty === "challenge" ? 4 : 0));
    const mk = (s: typeof sp, level: number) => ({
      name: s.name, element: s.element, level,
      maxHp: statAt(s.baseHp, level), atk: statAt(s.baseAtk, level),
      def: statAt(s.baseDef, level), spd: statAt(s.baseSpd, level),
    });
    const state = newBattle(mk(sp, m.level), mk(enemy.species, enemy.level));
    if (options.boss && region) {
      state.enemy.maxHp = Math.floor(state.enemy.maxHp * 1.6);
      state.enemy.hp = state.enemy.maxHp;
    }
    const [b] = await tx
      .insert(battles)
      .values({
        playerId, playerMonsterId: m.id, enemySpeciesId: enemy.species.id,
        enemyLevel: enemy.level, seed, state, regionId: region?.id, boss: !!region && !!options.boss, difficulty, rulesVersion: "pve-v2",
      })
      .returning();
    return { ...battleView(b), resumed: false };
  });
}

export async function getBattle(playerId: string, battleId: string) {
  const [b] = await db
    .select()
    .from(battles)
    .where(and(eq(battles.id, battleId), eq(battles.playerId, playerId)));
  if (!b) throw new HttpError(404, "battle_not_found");
  const turns = await db.select().from(battleTurns).where(eq(battleTurns.battleId,b.id))
    .orderBy(asc(battleTurns.turnNo),asc(battleTurns.createdAt));
  const events = turns.flatMap(t => {
    const result = t.result as TurnEvent | { events: TurnEvent[] };
    return "events" in result ? result.events : [result];
  });
  return battleView(b,events);
}

/** The client only sends an action name; everything else is computed here. */
export async function playAction(playerId: string, battleId: string, action: Action,
  request: { actionId: string; expectedTurn: number }) {
  return db.transaction(async (tx) => {
    await tx.select({ id: players.id }).from(players).where(eq(players.id, playerId)).for("update");
    const [b] = await tx
      .select()
      .from(battles)
      .where(and(eq(battles.id, battleId), eq(battles.playerId, playerId)))
      .for("update");
    if (!b) throw new HttpError(404, "battle_not_found");
    const [saved] = await tx.select().from(battleActions).where(and(
      eq(battleActions.battleId, b.id), eq(battleActions.actionId, request.actionId)));
    if (saved) {
      if (saved.action !== action || saved.expectedTurn !== request.expectedTurn) throw new HttpError(409, "action_id_reused");
      return saved.response as ReturnType<typeof battleView>;
    }
    if (b.status !== "active") throw new HttpError(409, "battle_finished");
    if (b.rulesVersion !== "pve-v2") throw new HttpError(409, "legacy_battle_restart_required");
    if (request.expectedTurn !== b.turnNo) throw new HttpError(409, "stale_turn");

    let result;
    try {
      result = resolveTurn(b.state as BattleState, action, b.seed);
    } catch (e) {
      if (e instanceof CombatError) {
        if (e.code === "skill_on_cooldown") log.warn("anticheat.impossible_action", { playerId, battleId, action });
        throw new HttpError(409, e.code);
      }
      throw e;
    }
    const { state, events } = result;

    await tx.insert(battleTurns).values(
      (["player", "enemy"] as const).filter(actor => events.some(ev => ev.actor === actor)).map(actor => ({
        battleId, turnNo: state.turn, actor,
        action: events.find(ev => ev.actor === actor)!.action,
        result: { events: events.filter(ev => ev.actor === actor) },
      })),
    );

    let status: BattleRow["status"] = "active";
    let rewardGold = 0;
    let rewardXp = 0;
    if (state.winner) {
      status = state.winner === "player" ? "won" : state.winner === "draw" ? "draw" : "lost";
      if (status === "won") {
        const rw = winRewards(b.enemyLevel);
        const multiplier = b.difficulty === "challenge" ? 2 : b.difficulty === "hard" ? 1.5 : 1;
        rewardGold = Math.floor(rw.gold * multiplier);
        rewardXp = Math.floor(rw.xp * multiplier);
        await applyLedger(tx, { playerId, currency: "crystals", delta: 1, reason: "pve_win",
          refType: "battle", refId: b.id, idempotencyKey: `battle:${b.id}:crystals` });
        if (b.boss && b.regionId) {
          const [first] = await tx.insert(progressionClaims).values({ playerId, claimId: `boss:${b.regionId}` })
            .onConflictDoNothing().returning();
          if (first) {
            rewardGold += 300; rewardXp += 200;
            await applyLedger(tx, { playerId, currency: "crystals", delta: 10, reason: "boss_first_win",
              idempotencyKey: `boss:${playerId}:${b.regionId}:crystals` });
          }
        }
        await applyLedger(tx, {
          playerId, currency: "gold", delta: rewardGold, reason: "pve_win",
          refType: "battle", refId: b.id, idempotencyKey: `battle:${b.id}:gold`,
        });
        const [m] = await tx.select().from(playerMonsters).where(eq(playerMonsters.id, b.playerMonsterId)).for("update");
        const next = applyXp(m.level, m.xp, rewardXp);
        await tx.update(playerMonsters).set(next).where(eq(playerMonsters.id, m.id));
      }
      await audit(tx, {
        actor: playerId, action: "battle.finished", targetType: "battle", targetId: b.id,
        metadata: { status, turns: state.turn, rewardGold, rewardXp },
      });
    }

    const [updated] = await tx
      .update(battles)
      .set({
        state, turnNo: state.turn, status, rewardGold, rewardXp,
        finishedAt: state.winner ? new Date() : null,
      })
      .where(eq(battles.id, b.id))
      .returning();
    const response = battleView(updated, events);
    await tx.insert(battleActions).values({ battleId: b.id, ...request, action, response });
    return response;
  });
}
