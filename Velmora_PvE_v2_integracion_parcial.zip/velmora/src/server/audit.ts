import { auditLogs } from "@/db/schema";
import type { Db, Tx } from "@/db";

/** Writes an append-only audit record. Never put secrets in `metadata`. */
export async function audit(
  conn: Db | Tx,
  e: {
    actor?: string | null;
    action: string;
    targetType?: string;
    targetId?: string;
    metadata?: Record<string, unknown>;
  },
) {
  await conn.insert(auditLogs).values({
    actorPlayerId: e.actor ?? null,
    action: e.action,
    targetType: e.targetType,
    targetId: e.targetId,
    metadata: e.metadata ?? {},
  });
}
