import { count, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, battles, paymentOrders, players, telegramIdentities } from "@/db/schema";
import { audit } from "./audit";
import { applyLedger, type Currency } from "./economy";
import { HttpError } from "./http";

export async function searchPlayers(q: string) {
  const term = `%${q.replace(/[%_\\]/g, "")}%`;
  return db
    .select({
      id: players.id, displayName: players.displayName, role: players.role, status: players.status,
      bannedReason: players.bannedReason, telegramUserId: telegramIdentities.telegramUserId,
      username: telegramIdentities.username, createdAt: players.createdAt,
    })
    .from(players)
    .leftJoin(telegramIdentities, eq(telegramIdentities.playerId, players.id))
    .where(q ? or(ilike(players.displayName, term), ilike(telegramIdentities.username, term)) : undefined)
    .orderBy(desc(players.createdAt))
    .limit(50);
}

export async function setBan(adminId: string, targetId: string, banned: boolean, reason: string) {
  if (adminId === targetId) throw new HttpError(400, "cannot_ban_self");
  return db.transaction(async (tx) => {
    const [t] = await tx.select().from(players).where(eq(players.id, targetId)).for("update");
    if (!t) throw new HttpError(404, "player_not_found");
    if (t.role === "admin") throw new HttpError(409, "cannot_ban_admin");
    await tx
      .update(players)
      .set(banned ? { status: "banned", bannedReason: reason, bannedAt: new Date() } : { status: "active", bannedReason: null, bannedAt: null })
      .where(eq(players.id, targetId));
    await audit(tx, { actor: adminId, action: banned ? "admin.ban" : "admin.unban", targetType: "player", targetId, metadata: { reason } });
    return { id: targetId, status: banned ? "banned" : "active" };
  });
}

/** Manual grant/revoke. Requires a caller-supplied idempotency key and always audited. */
export async function adminAdjust(adminId: string, p: { playerId: string; currency: Currency; amount: number; reason: string; requestId: string }) {
  return db.transaction(async (tx) => {
    const [t] = await tx.select({ id: players.id }).from(players).where(eq(players.id, p.playerId));
    if (!t) throw new HttpError(404, "player_not_found");
    const r = await applyLedger(tx, {
      playerId: p.playerId, currency: p.currency, delta: p.amount, reason: `admin:${p.reason}`.slice(0, 120),
      refType: "admin", refId: adminId, idempotencyKey: `admin:${p.requestId}`,
    });
    if (r.applied) {
      await audit(tx, { actor: adminId, action: "admin.adjust_balance", targetType: "player", targetId: p.playerId, metadata: { currency: p.currency, amount: p.amount, reason: p.reason } });
    }
    return r;
  });
}

export async function metrics() {
  const [pl] = await db.select({ n: count() }).from(players);
  const [banned] = await db.select({ n: count() }).from(players).where(eq(players.status, "banned"));
  const [bt] = await db.select({ n: count() }).from(battles);
  const [active24] = await db.select({ n: count() }).from(players).where(sql`${players.lastSeenAt} > now() - interval '24 hours'`);
  const [rev] = await db
    .select({ n: count(), stars: sql<number>`coalesce(sum(${paymentOrders.amount}), 0)::int` })
    .from(paymentOrders)
    .where(eq(paymentOrders.status, "confirmed"));
  const product = (await db.execute<{
    wins: number; draws: number; avg_turns: number; captures: number;
    first_capture_seconds: number | null; evolved_players: number;
  }>(sql`
    select
      (select count(*)::int from battles where status='won') as wins,
      (select count(*)::int from battles where status='draw') as draws,
      (select coalesce(avg(turn_no),0)::float from battles where status in ('won','lost','draw')) as avg_turns,
      (select count(*)::int from battles where capture_result->>'success'='true') as captures,
      (select avg(extract(epoch from (c.first_capture-p.created_at)))::float
       from players p join (select player_id,min(finished_at) first_capture from battles
         where capture_result->>'success'='true' group by player_id) c on c.player_id=p.id) as first_capture_seconds,
      (select count(distinct player_id)::int from player_monsters where species_id not like '%_1') as evolved_players
  `)).rows[0];
  const delivery = (await db.execute<{ missing: number }>(sql`
    select count(*)::int missing from payment_orders o
    where o.status='confirmed' and exists (
      select 1 from jsonb_each(coalesce(o.product_snapshot->'grants','{}'::jsonb)) g
      where g.key in ('gold','crystals') and (g.value::text)::int > 0
      and not exists(select 1 from ledger_entries l where l.idempotency_key='payment:'||o.id::text||':'||g.key)
    )
  `)).rows[0];
  return {
    ...product, confirmedOrdersMissingDelivery: delivery.missing,
    players: pl.n, bannedPlayers: banned.n, activeLast24h: active24.n, battles: bt.n,
    confirmedPayments: rev.n, starsRevenue: rev.stars,
  };
}

export const recentAudit = () => db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(100);
