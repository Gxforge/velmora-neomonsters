/**
 * Server-authoritative combat engine (pure, deterministic).
 * The client may only REQUEST an action ("attack" | "skill" | "guard").
 * Damage, crits, turn order, enemy behaviour and the winner are computed
 * here from the stored battle seed; nothing numeric is accepted from clients.
 */
import type { Element } from "./catalog";
import { rngFor } from "./rng";

export type Action = "attack" | "skill" | "guard";
export const ACTIONS: readonly Action[] = ["attack", "skill", "guard"];
export const MAX_TURNS = 40;
export const SKILL_COOLDOWN = 3;

export type Fighter = {
  name: string;
  element: Element;
  level: number;
  maxHp: number;
  hp: number;
  atk: number;
  def: number;
  spd: number;
  skillCooldown: number;
  guarding: boolean;
  effects?: { burn: number; weak: number; shield: number; haste: number };
};

export type BattleState = {
  player: Fighter;
  enemy: Fighter;
  turn: number;
  winner: "player" | "enemy" | "draw" | null;
};

export type TurnEvent = {
  actor: "player" | "enemy";
  action: Action;
  damage: number;
  crit: boolean;
  effectiveness: "super" | "resisted" | "normal";
  targetHp: number;
  effect?: string;
  actorHp?: number;
  kind?: "action" | "status";
};

export class CombatError extends Error {
  constructor(public readonly code: "battle_over" | "skill_on_cooldown" | "invalid_action") {
    super(code);
  }
}

// water > fire > earth > lightning > water ; light <-> dark
const STRONG_AGAINST: Record<Element, Element[]> = {
  water: ["fire"],
  fire: ["earth"],
  earth: ["lightning"],
  lightning: ["water"],
  light: ["dark"],
  dark: ["light"],
};

export function elementMultiplier(att: Element, def: Element): number {
  if (STRONG_AGAINST[att].includes(def)) return 1.5;
  if (STRONG_AGAINST[def].includes(att) && !STRONG_AGAINST[att].includes(def)) {
    // light/dark are mutually strong -> never "resisted"
    return att === "light" || att === "dark" ? 1 : 0.67;
  }
  return 1;
}

export function newBattle(player: Omit<Fighter, "skillCooldown" | "guarding" | "hp">, enemy: Omit<Fighter, "skillCooldown" | "guarding" | "hp">): BattleState {
  const mk = (f: typeof player): Fighter => ({ ...f, hp: f.maxHp, skillCooldown: 0, guarding: false });
  return { player: mk(player), enemy: mk(enemy), turn: 0, winner: null };
}

type Rng = () => number;

function strike(att: Fighter, def: Fighter, action: Action, rng: Rng) {
  // always consume RNG in the same order => reproducible replays
  const critRoll = rng();
  const varianceRoll = rng();
  if (action === "guard") return { damage: 0, crit: false, effectiveness: "normal" as const };
  const power = action === "skill" ? 70 : 40;
  const base = Math.floor((((2 * att.level) / 5 + 2) * power * att.atk) / Math.max(1, def.def) / 50) + 2;
  const mult = elementMultiplier(att.element, def.element);
  const crit = critRoll < 0.1;
  const raw = base * mult * (crit ? 1.5 : 1) * (0.85 + varianceRoll * 0.15)
    * (def.guarding ? 0.5 : 1) * ((def.effects?.shield ?? 0) > 0 ? 0.75 : 1)
    * ((att.effects?.weak ?? 0) > 0 ? 0.8 : 1);
  return {
    damage: Math.max(1, Math.floor(raw)),
    crit,
    effectiveness: mult > 1 ? ("super" as const) : mult < 1 ? ("resisted" as const) : ("normal" as const),
  };
}

export function enemyIntent(state: BattleState): Action {
  // Visible, reproducible pattern: no hidden random intent changes.
  if (state.enemy.skillCooldown === 0 && (state.turn + 1) % 3 === 0) return "skill";
  if ((state.turn + 1) % 4 === 0) return "guard";
  return "attack";
}

/** Resolves ONE full turn (both sides act, by speed). Returns a new state. */
export function resolveTurn(
  prev: BattleState,
  playerAction: Action,
  seed: string,
): { state: BattleState; events: TurnEvent[] } {
  if (!ACTIONS.includes(playerAction)) throw new CombatError("invalid_action");
  if (prev.winner) throw new CombatError("battle_over");
  if (playerAction === "skill" && prev.player.skillCooldown > 0) {
    throw new CombatError("skill_on_cooldown");
  }

  const state: BattleState = structuredClone(prev);
  state.turn += 1;
  const rng = rngFor(seed, state.turn);
  const enemyChoice = enemyIntent(prev);
  // Defence starts before either fighter acts and expires at round end.
  state.player.guarding = playerAction === "guard";
  state.enemy.guarding = enemyChoice === "guard";
  for (const f of [state.player, state.enemy]) f.effects ??= { burn: 0, weak: 0, shield: 0, haste: 0 };

  const speed = (f: Fighter) => f.spd * ((f.effects?.haste ?? 0) > 0 ? 1.3 : 1);
  const playerFirst = speed(state.player) >= speed(state.enemy);
  const order: Array<["player" | "enemy", Action]> = playerFirst
    ? [["player", playerAction], ["enemy", enemyChoice]]
    : [["enemy", enemyChoice], ["player", playerAction]];

  const events: TurnEvent[] = [];
  for (const [who, action] of order) {
    const att = who === "player" ? state.player : state.enemy;
    const def = who === "player" ? state.enemy : state.player;
    if (att.hp <= 0) continue; // fainted before acting
    const res = strike(att, def, action, rng);
    if (action === "guard") att.guarding = true;
    if (action === "skill") att.skillCooldown = SKILL_COOLDOWN + 1; // decremented at end of turn
    def.hp = Math.max(0, def.hp - res.damage);
    let effect: string | undefined;
    if (action === "skill") {
      switch (att.element) {
        case "fire": def.effects!.burn = 3; effect = "burn"; break;
        case "water": att.hp = Math.min(att.maxHp, att.hp + Math.max(1, Math.floor(att.maxHp * 0.12))); effect = "heal"; break;
        case "earth": att.effects!.shield = 3; effect = "shield"; break;
        case "lightning": att.effects!.haste = 3; effect = "haste"; break;
        case "light": att.effects!.burn = 0; att.effects!.weak = 0; effect = "cleanse"; break;
        case "dark": def.effects!.weak = 3; effect = "weak"; break;
      }
    }
    events.push({ actor: who, action, damage: res.damage, crit: res.crit,
      effectiveness: res.effectiveness, targetHp: def.hp, effect, actorHp: att.hp, kind: "action" });
  }

  for (const who of ["player", "enemy"] as const) {
    const f = state[who];
    if (f.hp > 0 && f.effects!.burn > 0) {
      const damage = Math.max(1, Math.floor(f.maxHp * 0.05));
      f.hp = Math.max(0, f.hp - damage);
      events.push({ actor: who === "player" ? "enemy" : "player", action: "skill",
        damage, crit: false, effectiveness: "normal", targetHp: f.hp, effect: "burn_tick", kind: "status" });
    }
    for (const key of ["burn", "weak", "shield", "haste"] as const) f.effects![key] = Math.max(0, f.effects![key] - 1);
    f.guarding = false;
  }
  state.player.skillCooldown = Math.max(0, state.player.skillCooldown - 1);
  state.enemy.skillCooldown = Math.max(0, state.enemy.skillCooldown - 1);

  if (state.enemy.hp <= 0 && state.player.hp <= 0) state.winner = "draw";
  else if (state.enemy.hp <= 0) state.winner = "player";
  else if (state.player.hp <= 0) state.winner = "enemy";
  else if (state.turn >= MAX_TURNS) state.winner = "draw";

  return { state, events };
}
