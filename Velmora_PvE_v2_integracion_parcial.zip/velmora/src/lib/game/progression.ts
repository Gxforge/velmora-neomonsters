import { SPECIES, type SpeciesDef } from "./catalog";
import { rngFor } from "./rng";

export const MAX_LEVEL = 100;

export const statAt = (base: number, level: number) =>
  Math.floor(base * (1 + 0.12 * (level - 1)));

/** XP needed to go from `level` to `level + 1`. */
export const xpToNext = (level: number) => 40 + level * level * 2;

export function applyXp(level: number, xp: number, gain: number) {
  let l = level;
  let x = xp + Math.max(0, Math.floor(gain));
  while (l < MAX_LEVEL && x >= xpToNext(l)) {
    x -= xpToNext(l);
    l++;
  }
  if (l >= MAX_LEVEL) x = 0;
  return { level: l, xp: x };
}

/** Evolution requirements, enforced server-side. Key = current stage. */
export const EVOLUTION_RULES: Record<1 | 2, { minLevel: number; gold: number; crystals: number }> = {
  1: { minLevel: 16, gold: 500, crystals: 0 },
  2: { minLevel: 36, gold: 2000, crystals: 25 },
};

export type EvolutionCheck =
  | { ok: true; cost: { gold: number; crystals: number } }
  | { ok: false; reason: "max_stage" | "level_too_low" };

export function checkEvolution(stage: number, level: number): EvolutionCheck {
  if (stage >= 3) return { ok: false, reason: "max_stage" };
  const rule = EVOLUTION_RULES[stage as 1 | 2];
  if (level < rule.minLevel) return { ok: false, reason: "level_too_low" };
  return { ok: true, cost: { gold: rule.gold, crystals: rule.crystals } };
}

export const winRewards = (enemyLevel: number) => ({
  gold: 20 + enemyLevel * 5,
  xp: 30 + enemyLevel * 10,
});

/** Deterministic enemy selection from the battle seed (server decides). */
export function pickEnemy(seed: string, playerLevel: number): { species: SpeciesDef; level: number } {
  const rng = rngFor(seed, "enemy");
  const offset = Math.floor(rng() * 3) - 1; // -1, 0, +1
  const level = Math.min(MAX_LEVEL, Math.max(1, playerLevel + offset));
  const stage = level < EVOLUTION_RULES[1].minLevel ? 1 : level < EVOLUTION_RULES[2].minLevel ? 2 : 3;
  const pool = SPECIES.filter((s) => s.stage === stage);
  return { species: pool[Math.floor(rng() * pool.length)], level };
}
