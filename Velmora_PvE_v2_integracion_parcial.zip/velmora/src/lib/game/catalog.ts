/**
 * Static game catalog: 6 elemental evolution lines x 3 stages = 18 species,
 * and store products. Names/stats are the launch design; the DB tables
 * monster_species/products are synced from here by ensureCatalog().
 * NOTE: art for these species is tracked in ASSET_AUDIT.md (not all final).
 */
export const ELEMENTS = ["fire", "water", "earth", "lightning", "light", "dark"] as const;
export type Element = (typeof ELEMENTS)[number];

export type SpeciesDef = {
  id: string;
  lineId: Element;
  name: string;
  element: Element;
  stage: 1 | 2 | 3;
  evolvesTo: string | null;
  baseHp: number;
  baseAtk: number;
  baseDef: number;
  baseSpd: number;
};

type LineDef = {
  element: Element;
  names: [string, string, string];
  /** relative stat profile for stage 1 */
  profile: { hp: number; atk: number; def: number; spd: number };
};

const LINES: LineDef[] = [
  { element: "fire", names: ["Cindrel", "Magmarel", "Pyrelord"], profile: { hp: 44, atk: 14, def: 9, spd: 11 } },
  { element: "water", names: ["Finlet", "Tidefin", "Leviarch"], profile: { hp: 48, atk: 12, def: 11, spd: 10 } },
  { element: "earth", names: ["Pebbleon", "Crystalback", "Mountarch"], profile: { hp: 54, atk: 11, def: 15, spd: 6 } },
  { element: "lightning", names: ["Zapling", "Voltrunner", "Tempestyr"], profile: { hp: 40, atk: 13, def: 8, spd: 16 } },
  { element: "light", names: ["Glimmite", "Seraphel", "Solarion"], profile: { hp: 46, atk: 12, def: 12, spd: 11 } },
  { element: "dark", names: ["Umbrel", "Gloomhorn", "Nyxarion"], profile: { hp: 42, atk: 15, def: 9, spd: 12 } },
];

const STAGE_MULT = [1, 1.5, 2.1] as const;

export const SPECIES: SpeciesDef[] = LINES.flatMap((line) =>
  ([1, 2, 3] as const).map((stage) => {
    const m = STAGE_MULT[stage - 1];
    return {
      id: `${line.element}_${stage}`,
      lineId: line.element,
      name: line.names[stage - 1],
      element: line.element,
      stage,
      evolvesTo: stage < 3 ? `${line.element}_${stage + 1}` : null,
      baseHp: Math.round(line.profile.hp * m),
      baseAtk: Math.round(line.profile.atk * m),
      baseDef: Math.round(line.profile.def * m),
      baseSpd: Math.round(line.profile.spd * m),
    };
  }),
);

export const SPECIES_BY_ID = new Map(SPECIES.map((s) => [s.id, s]));

/** Lines a new player may choose as starter (stage-1 only, server-validated). */
export const STARTER_LINES: Element[] = ["fire", "water", "earth"];
export const STARTER_GOLD = 100;

export type ProductDef = {
  id: string;
  name: string;
  description: string;
  starsPrice: number;
  grants: { crystals?: number; gold?: number };
};

/** Launch pricing is a configurable starting point, not a tuned economy. */
export const PRODUCTS: ProductDef[] = [
  { id: "crystals_small", name: "Crystal Pouch", description: "100 crystals", starsPrice: 50, grants: { crystals: 100 } },
  { id: "crystals_medium", name: "Crystal Chest", description: "550 crystals", starsPrice: 250, grants: { crystals: 550 } },
  { id: "gold_bundle", name: "Gold Bundle", description: "5,000 gold", starsPrice: 100, grants: { gold: 5000 } },
];

export const PRODUCT_BY_ID = new Map(PRODUCTS.map((p) => [p.id, p]));
