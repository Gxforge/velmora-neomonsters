import type { Element } from "./catalog";
export const SKILLS: Record<Element, { name: string; effect: string; role: string }> = {
 fire: { name: "Llama persistente", effect: "Daño y quemadura: 5% de vida máxima al final de 3 rondas, incluida esta.", role: "Atacante" },
 water: { name: "Marea vital", effect: "Daño y recuperación del 12% de vida máxima.", role: "Soporte" },
 earth: { name: "Bastión", effect: "Daño y escudo: reduce un 25% el daño recibido durante 3 rondas, incluida esta.", role: "Tanque" },
 lightning: { name: "Sobrecarga", effect: "Daño y +30% de velocidad en las 2 rondas siguientes.", role: "Velocista" },
 light: { name: "Purificación", effect: "Daño y limpieza de quemadura y debilidad.", role: "Soporte" },
 dark: { name: "Marchitar", effect: "Daño y debilidad: reduce un 20% el daño del rival durante 3 rondas, incluida esta.", role: "Especialista" },
};
