import type { Element } from "./catalog";
export const REGIONS: { id: string; name: string; minLevel: number; elements: Element[]; boss: string; description: string }[] = [
 { id: "grove", name: "Arboleda del Alba", minLevel: 1, elements: ["earth", "fire"], boss: "earth_1", description: "Aprende las afinidades y captura tu primera criatura." },
 { id: "coast", name: "Costa de Tormentas", minLevel: 8, elements: ["water", "lightning"], boss: "water_2", description: "Gestiona escudos y la velocidad del rival." },
 { id: "ruins", name: "Ruinas del Eclipse", minLevel: 16, elements: ["light", "dark"], boss: "dark_2", description: "Limpia estados y supera al guardián del eclipse." },
];
export const DIFFICULTIES = ["normal", "hard", "challenge"] as const;
export type Difficulty = typeof DIFFICULTIES[number];
export const QUESTS = [
 { id: "first-win", name: "Gana tu primer combate", metric: "wins", goal: 1, gold: 100, crystals: 3 },
 { id: "collector", name: "Reúne tres especies distintas", metric: "species", goal: 3, gold: 200, crystals: 10 },
 { id: "veteran", name: "Gana diez combates", metric: "wins", goal: 10, gold: 500, crystals: 15 },
 { id: "evolution", name: "Consigue una criatura evolucionada", metric: "evolved", goal: 1, gold: 500, crystals: 10 },
] as const;
export const captureChance = (ownedCount: number) => ownedCount <= 1 ? 1 : 0.65;
