import { createHmac, timingSafeEqual } from "node:crypto";

export type SessionPayload = {
  /** game account id (players.id) */
  pid: string;
  /** telegram user id (identity) */
  tg: number;
  /** expiry, unix seconds */
  exp: number;
};

const b64 = (b: Buffer) => b.toString("base64url");

/**
 * Stateless signed session token (HS256-like, `v1.<payload>.<sig>`).
 * Sent by the client as `Authorization: Bearer ...` (no cookies: Mini Apps
 * run in third-party webviews, and header auth removes CSRF exposure).
 * Authorization state (banned, role) is always re-read from the DB.
 */
export function signSession(
  data: { pid: string; tg: number },
  secret: string,
  ttlSec = 12 * 3600,
  nowMs = Date.now(),
): string {
  if (secret.length < 32) throw new Error("SESSION_SECRET must be at least 32 chars");
  const payload: SessionPayload = { ...data, exp: Math.floor(nowMs / 1000) + ttlSec };
  const body = b64(Buffer.from(JSON.stringify(payload)));
  const sig = b64(createHmac("sha256", secret).update(`v1.${body}`).digest());
  return `v1.${body}.${sig}`;
}

export function verifySession(
  token: string,
  secret: string,
  nowMs = Date.now(),
): SessionPayload | null {
  const parts = token.split(".");
  if (parts.length !== 3 || parts[0] !== "v1") return null;
  const expected = createHmac("sha256", secret).update(`v1.${parts[1]}`).digest();
  const got = Buffer.from(parts[2], "base64url");
  if (got.length !== expected.length || !timingSafeEqual(got, expected)) return null;
  try {
    const p = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8")) as SessionPayload;
    if (typeof p.pid !== "string" || !Number.isSafeInteger(p.tg)) return null;
    if (p.exp <= Math.floor(nowMs / 1000)) return null;
    return p;
  } catch {
    return null;
  }
}
