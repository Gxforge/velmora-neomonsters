import { createHmac, timingSafeEqual } from "node:crypto";

export type TelegramUser = {
  id: number;
  is_bot?: boolean;
  first_name?: string;
  last_name?: string;
  username?: string;
  language_code?: string;
};

export type InitDataErrorCode = "missing" | "malformed" | "bad_hash" | "expired" | "no_user";

export class InitDataError extends Error {
  constructor(public readonly code: InitDataErrorCode) {
    super(`initData rejected: ${code}`);
  }
}

export type ValidatedInitData = {
  user: TelegramUser;
  authDate: number;
  queryId?: string;
};

/**
 * Validates Telegram Mini App `initData` as documented by Telegram:
 * secret = HMAC_SHA256(key="WebAppData", msg=bot_token)
 * hash   = HMAC_SHA256(key=secret, msg=data_check_string)
 * Rejects tampered or stale (older than maxAgeSec) data.
 * Never trust `initDataUnsafe` from the client; only this server-side check.
 */
export function validateInitData(
  initData: string,
  botToken: string,
  opts: { maxAgeSec?: number; nowMs?: number } = {},
): ValidatedInitData {
  const maxAgeSec = opts.maxAgeSec ?? 3600;
  const nowSec = Math.floor((opts.nowMs ?? Date.now()) / 1000);

  if (!initData) throw new InitDataError("missing");
  if (initData.length > 4096) throw new InitDataError("malformed");

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash || !/^[0-9a-f]{64}$/.test(hash)) throw new InitDataError("malformed");
  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");

  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const expected = createHmac("sha256", secret).update(dataCheckString).digest();
  const received = Buffer.from(hash, "hex");
  if (received.length !== expected.length || !timingSafeEqual(received, expected)) {
    throw new InitDataError("bad_hash");
  }

  const authDate = Number(params.get("auth_date"));
  if (!Number.isInteger(authDate) || authDate <= 0) throw new InitDataError("malformed");
  if (nowSec - authDate > maxAgeSec || authDate - nowSec > 60) {
    throw new InitDataError("expired");
  }

  let user: TelegramUser;
  try {
    user = JSON.parse(params.get("user") ?? "");
  } catch {
    throw new InitDataError("no_user");
  }
  if (!user || !Number.isSafeInteger(user.id) || user.id <= 0 || user.is_bot) {
    throw new InitDataError("no_user");
  }

  return { user, authDate, queryId: params.get("query_id") ?? undefined };
}

/** Test/support helper: builds correctly-signed initData (used by tests only). */
export function signInitDataForTests(
  fields: Record<string, string>,
  botToken: string,
): string {
  const dcs = Object.entries(fields)
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const hash = createHmac("sha256", secret).update(dcs).digest("hex");
  return new URLSearchParams({ ...fields, hash }).toString();
}
