"use client";
export function playFeedback(kind: "hit" | "victory" | "evolve", enabled: boolean, vibration: boolean) {
 if (vibration && typeof navigator !== "undefined") navigator.vibrate?.(kind === "hit" ? 20 : [25,40,25]);
 if (!enabled) return;
 const audio = new Audio(`/assets/audio/${kind}.wav`);
 audio.volume = 0.2;
 void audio.play().catch(() => {});
}
