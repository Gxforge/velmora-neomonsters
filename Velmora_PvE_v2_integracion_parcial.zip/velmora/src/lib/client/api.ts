"use client";
import { useCallback, useEffect, useState } from "react";

export class ApiError extends Error {
  constructor(public status: number, public code: string) {
    super(code);
  }
}

type TgWebApp = {
  initData: string;
  ready: () => void;
  expand: () => void;
  openInvoice?: (url: string, cb: (status: string) => void) => void;
};
export const tgWebApp = (): TgWebApp | undefined =>
  (window as unknown as { Telegram?: { WebApp?: TgWebApp } }).Telegram?.WebApp;

const KEY = "velmora.session";

export async function api<T>(path: string, o: { method?: string; body?: unknown; token?: string | null } = {}): Promise<T> {
  const res = await fetch(path, {
    method: o.method ?? (o.body ? "POST" : "GET"),
    headers: { "content-type": "application/json", ...(o.token ? { authorization: `Bearer ${o.token}` } : {}) },
    body: o.body ? JSON.stringify(o.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, (data as { error?: string }).error ?? "error");
  return data as T;
}

/** Authenticates with Telegram initData (validated by the server) and keeps the session token. */
export function useSession() {
  const [token, setToken] = useState<string | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "no-telegram" | "banned" | "error">("loading");

  const login = useCallback(async () => {
    const tg = tgWebApp();
    if (!tg?.initData) {
      setState("no-telegram");
      return null;
    }
    tg.ready();
    tg.expand();
    try {
      const r = await api<{ token: string }>("/api/auth/telegram", { body: { initData: tg.initData } });
      sessionStorage.setItem(KEY, r.token);
      setToken(r.token);
      setState("ready");
      return r.token;
    } catch (e) {
      setState(e instanceof ApiError && e.code === "banned" ? "banned" : "error");
      return null;
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => void login(), 0);
    return () => clearTimeout(t);
  }, [login]);

  return { token, state, relogin: login };
}
