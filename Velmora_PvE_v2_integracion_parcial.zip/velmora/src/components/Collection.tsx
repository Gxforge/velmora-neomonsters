"use client";
import { useState } from "react";
import type { Element } from "@/lib/game/catalog";
import { SKILLS } from "@/lib/game/skills";
import { Creature } from "./Creature";
export type Monster = { id: string; speciesId: string; name: string; element: Element; stage: number; level: number;
 xp: number; xpToNext: number; stats: { hp: number; atk: number; def: number; spd: number }; canEvolve: boolean;
 evolution: { minLevel: number; gold: number; crystals: number; target: { name: string; baseHp: number; baseAtk: number; baseDef: number; baseSpd: number } } | null };
export function Collection({ monsters, selected, choose, evolve, busy, balances }: { monsters: Monster[]; selected: string;
 choose: (id: string) => void; evolve: (id: string) => void; busy: boolean; balances: { gold: number; crystals: number } }) {
 const [filter, setFilter] = useState("all");
 const [sort, setSort] = useState("level");
 const list = monsters.filter(m => filter === "all" || m.element === filter).sort((a,b) => sort === "level" ? b.level-a.level : a.name.localeCompare(b.name));
 return <section className="space-y-3"><h2>Criaturas</h2>
 <div className="flex gap-2"><label>Elemento <select value={filter} onChange={e => setFilter(e.target.value)}>
 {["all","fire","water","earth","lightning","light","dark"].map(e => <option key={e}>{e}</option>)}</select></label>
 <label>Orden <select value={sort} onChange={e => setSort(e.target.value)}><option value="level">Nivel</option><option value="name">Nombre</option></select></label></div>
 {list.map(m => { const ev = m.evolution; const afford = !!ev && balances.gold >= ev.gold && balances.crystals >= ev.crystals;
 return <article className={`card ${selected===m.id ? "selected" : ""}`} key={m.id}>
 <div className="flex gap-3"><Creature element={m.element} stage={m.stage} name={m.name}/><div><h3>{m.name}</h3>
 <p>Nv. {m.level} · {m.element} · etapa {m.stage}</p><p>{SKILLS[m.element].role}</p>
 <p>HP {m.stats.hp} · ATK {m.stats.atk} · DEF {m.stats.def} · SPD {m.stats.spd}</p></div></div>
 <progress aria-label="Experiencia" max={m.xpToNext} value={m.xp}/><p>XP {m.xp}/{m.xpToNext}</p>
 <details><summary>{SKILLS[m.element].name}</summary><p>{SKILLS[m.element].effect}</p><p>Enfriamiento: 3 rondas.</p></details>
 <button disabled={busy} onClick={() => choose(m.id)}>{selected===m.id ? "Combatiente seleccionado" : "Seleccionar"}</button>
 {ev && <details><summary>Evolución → {ev.target.name}</summary>
 <p>Requiere nivel {ev.minLevel}, {ev.gold} oro y {ev.crystals} cristales.</p>
 <p>Estadísticas base siguientes: HP {ev.target.baseHp} · ATK {ev.target.baseAtk} · DEF {ev.target.baseDef} · SPD {ev.target.baseSpd}</p>
 {!afford && <p>Faltan {Math.max(0,ev.gold-balances.gold)} oro y {Math.max(0,ev.crystals-balances.crystals)} cristales.</p>}
 <button disabled={busy || !m.canEvolve || !afford} onClick={() => { if (window.confirm(`¿Evolucionar a ${ev.target.name} por ${ev.gold} oro y ${ev.crystals} cristales?`)) evolve(m.id); }}>Confirmar evolución</button>
 </details>}</article>; })}</section>;
}
