"use client";
import { useState } from "react";
export function Creature({ element, stage = 1, name, size = 96 }: { element: string; stage?: number; name: string; size?: number }) {
 const [failed, setFailed] = useState(false);
 return <span className="creature" role="img" aria-label={name} style={{ width: size, height: size }}>
   {failed ? <span>{name.slice(0, 2)}<br/>{element}</span> :
   /* eslint-disable-next-line @next/next/no-img-element */
   <img className="pixel" src={`/assets/evolution/${element}.png`} alt="" onError={() => setFailed(true)}
     style={{ width: size * 3, height: size, maxWidth: "none", transform: `translateX(-${(stage - 1) * size}px)` }} />}
 </span>;
}
