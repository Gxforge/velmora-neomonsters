"use client";
import type { Difficulty } from "@/lib/game/adventure";
import { Creature } from "./Creature";
export type Adventure = {
 tutorial: { starter: boolean; battle: boolean; capture: boolean };
 regions: { id: string; name: string; minLevel: number; description: string; unlocked: boolean; completed: boolean }[];
 bestiary: { id: string; name: string; element: string; stage: number; owned: boolean; discovered: boolean; location: string }[];
 quests: { id: string; name: string; progress: number; goal: number; claimed: boolean; gold: number; crystals: number }[];
 history: { id: string; status: string; turn: number; regionId: string | null }[];
};
export function AdventurePanel({ data, level, busy, start, claim, difficulty, setDifficulty }: {
 data: Adventure; level: number; busy: boolean; start: (region: string, boss: boolean) => void;
 claim: (id: string) => void; difficulty: Difficulty; setDifficulty: (d: Difficulty) => void;
}) {
 return <section className="space-y-4">
 <h2>Aventura</h2>
 <p>Selecciona tu criatura en Colección. Vence al jefe para desbloquear la siguiente región.</p>
 <label>Dificultad <select value={difficulty} onChange={e => setDifficulty(e.target.value as Difficulty)}>
 <option value="normal">Normal · recompensas ×1</option><option value="hard">Difícil · nivel +2 · ×1,5</option>
 <option value="challenge">Desafío · nivel +4 · ×2</option></select></label>
 {data.regions.map(r => <article className="card" key={r.id}>
 <h3>{r.name} {r.completed ? "✓" : ""}</h3><p>{r.description}</p><p>Nivel mínimo: {r.minLevel}</p>
 <div className="flex gap-2"><button disabled={busy || !r.unlocked || level < r.minLevel} onClick={() => start(r.id, false)}>Explorar</button>
 <button disabled={busy || !r.unlocked || level < r.minLevel} onClick={() => start(r.id, true)}>Desafiar al jefe</button></div>
 {!r.unlocked && <p>Derrota al jefe anterior.</p>}</article>)}
 <h2>Misiones</h2>{data.quests.map(q => <article className="card" key={q.id}><h3>{q.name}</h3>
 <p>{Math.min(q.goal, q.progress)}/{q.goal} · {q.gold} oro + {q.crystals} cristales</p>
 <button disabled={busy || q.claimed || q.progress < q.goal} onClick={() => claim(q.id)}>{q.claimed ? "Reclamada" : "Reclamar"}</button></article>)}
 </section>;
}
export function Bestiary({ data }: { data: Adventure }) {
 return <details className="card"><summary>Bestiario · {data.bestiary.filter(s => s.owned).length}/{data.bestiary.length}</summary>
 <div className="grid grid-cols-2 gap-2">{data.bestiary.map(s => <article key={s.id} className="card">
 {s.discovered && <Creature element={s.element} stage={s.stage} name={s.name}/>}<h3>{s.discovered ? s.name : "Desconocida"}</h3>
 <p>{s.element} · etapa {s.stage} · {s.owned ? "Obtenida" : s.discovered ? "Descubierta" : "Sin descubrir"}</p><p>{s.location}</p>
 </article>)}</div></details>;
}
