import { z } from "zod";
import { requirePlayer } from "@/server/auth";
import { handle, json, parseBody } from "@/server/http";
import { chooseStarter } from "@/server/monsters";
import { rateLimit } from "@/server/rateLimit";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  const player = await requirePlayer(req);
  await rateLimit(`starter:${player.id}`, 10, 60);
  const { lineId } = await parseBody(req, z.object({ lineId: z.string().max(20) }));
  return json(await chooseStarter(player.id, lineId), 201);
});
