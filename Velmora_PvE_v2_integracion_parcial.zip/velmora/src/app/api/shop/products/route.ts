import { requirePlayer } from "@/server/auth";
import { ensureCatalog } from "@/server/catalog-sync";
import { handle, json } from "@/server/http";
import { listProducts } from "@/server/profile";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: Request) => {
  await requirePlayer(req);
  await ensureCatalog();
  return json({ products: await listProducts() });
});
