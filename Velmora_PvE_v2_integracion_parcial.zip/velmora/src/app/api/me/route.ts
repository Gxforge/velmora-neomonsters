import { requirePlayer } from "@/server/auth";
import { handle, json } from "@/server/http";
import { getProfile } from "@/server/profile";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: Request) => {
  const player = await requirePlayer(req);
  return json(await getProfile(player));
});
