import { z } from "zod";
import { setBan } from "@/server/admin";
import { requireAdmin } from "@/server/auth";
import { handle, HttpError, json, parseBody } from "@/server/http";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const admin = await requireAdmin(req);
  const id = z.string().uuid().safeParse((await ctx.params).id);
  if (!id.success) throw new HttpError(400, "invalid_request");
  const body = await parseBody(req, z.object({ banned: z.boolean(), reason: z.string().min(3).max(200) }));
  return json(await setBan(admin.id, id.data, body.banned, body.reason));
});
