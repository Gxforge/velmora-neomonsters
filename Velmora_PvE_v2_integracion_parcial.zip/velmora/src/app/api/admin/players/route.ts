import { searchPlayers } from "@/server/admin";
import { requireAdmin } from "@/server/auth";
import { handle, json } from "@/server/http";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: Request) => {
  await requireAdmin(req);
  const q = (new URL(req.url).searchParams.get("q") ?? "").slice(0, 40);
  return json({ players: await searchPlayers(q) });
});
