import { z } from "zod";
import { adminAdjust } from "@/server/admin";
import { requireAdmin } from "@/server/auth";
import { handle, json, parseBody } from "@/server/http";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  const admin = await requireAdmin(req);
  const b = await parseBody(
    req,
    z.object({
      playerId: z.string().uuid(),
      currency: z.enum(["gold", "crystals"]),
      amount: z.number().int().refine((n) => n !== 0 && Math.abs(n) <= 1_000_000),
      reason: z.string().min(3).max(100),
      requestId: z.string().min(8).max(64),
    }),
  );
  return json(await adminAdjust(admin.id, b));
});
