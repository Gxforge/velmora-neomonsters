import { recentAudit } from "@/server/admin";
import { requireAdmin } from "@/server/auth";
import { handle, json } from "@/server/http";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: Request) => {
  await requireAdmin(req);
  return json({ logs: await recentAudit() });
});
