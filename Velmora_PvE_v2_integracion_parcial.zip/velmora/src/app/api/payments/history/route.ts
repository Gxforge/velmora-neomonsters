import { requirePlayer } from "@/server/auth";
import { paymentHistory } from "@/server/adventure";
import { handle, json } from "@/server/http";

import { rateLimit } from "@/server/rateLimit";
export const dynamic = "force-dynamic";
export const GET = handle(async (req: Request) => {
 const player = await requirePlayer(req);
 await rateLimit(`payments/history:${player.id}`, 120, 60);
 return json({ orders: await paymentHistory(player.id) });
});
