import { z } from "zod";
import { requirePlayer } from "@/server/auth";
import { handle, json, parseBody } from "@/server/http";
import { createStarsInvoice } from "@/server/payments";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  const player = await requirePlayer(req);
  const { productId } = await parseBody(req, z.object({ productId: z.string().max(40) }));
  return json(await createStarsInvoice(player, productId), 201);
});
