import { requirePlayer } from "@/server/auth";
import { adventureView } from "@/server/adventure";
import { handle, json } from "@/server/http";

import { rateLimit } from "@/server/rateLimit";
export const dynamic = "force-dynamic";
export const GET = handle(async (req: Request) => {
 const player = await requirePlayer(req);
 await rateLimit(`adventure:${player.id}`, 120, 60);
 return json(await adventureView(player.id));
});
