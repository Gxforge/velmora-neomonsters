import { z } from "zod";
import { loginWithTelegram } from "@/server/auth";
import { clientIp, handle, json, parseBody } from "@/server/http";
import { rateLimit } from "@/server/rateLimit";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  await rateLimit(`login-ip:${clientIp(req)}`, 30, 60);
  const { initData } = await parseBody(req, z.object({ initData: z.string().min(1).max(4096) }));
  return json(await loginWithTelegram(initData));
});
