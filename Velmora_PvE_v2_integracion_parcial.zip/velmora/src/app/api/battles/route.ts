import { z } from "zod";
import { requirePlayer } from "@/server/auth";
import { startPve } from "@/server/battles";
import { handle, json, parseBody } from "@/server/http";
import { rateLimit } from "@/server/rateLimit";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  const player = await requirePlayer(req);
  await rateLimit(`battle-start:${player.id}`, 30, 60);
  const { monsterId, ...options } = await parseBody(req, z.object({ monsterId: z.string().uuid(),
    regionId: z.enum(["grove", "coast", "ruins"]).optional(), boss: z.boolean().optional(),
    difficulty: z.enum(["normal", "hard", "challenge"]).optional() }));
  return json(await startPve(player.id, monsterId, options), 201);
});
