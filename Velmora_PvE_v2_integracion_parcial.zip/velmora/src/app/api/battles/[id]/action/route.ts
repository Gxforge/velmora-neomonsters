import { z } from "zod";
import { requirePlayer } from "@/server/auth";
import { playAction } from "@/server/battles";
import { handle, HttpError, json, parseBody } from "@/server/http";
import { rateLimit } from "@/server/rateLimit";

export const dynamic = "force-dynamic";

// The client may ONLY name an action. No damage/crit/winner fields are read.
export const POST = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const player = await requirePlayer(req);
  await rateLimit(`battle-action:${player.id}`, 120, 60);
  const id = z.string().uuid().safeParse((await ctx.params).id);
  if (!id.success) throw new HttpError(400, "invalid_request");
  const { action, ...request } = await parseBody(req, z.object({ action: z.enum(["attack", "skill", "guard"]),
    actionId: z.string().uuid(), expectedTurn: z.number().int().min(0).max(40) }));
  return json(await playAction(player.id, id.data, action, request));
});
