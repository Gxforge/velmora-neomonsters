import { z } from "zod";
import { requirePlayer } from "@/server/auth";
import { getBattle } from "@/server/battles";
import { handle, HttpError, json } from "@/server/http";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const player = await requirePlayer(req);
  const id = z.string().uuid().safeParse((await ctx.params).id);
  if (!id.success) throw new HttpError(400, "invalid_request");
  return json(await getBattle(player.id, id.data));
});
