import { requirePlayer } from "@/server/auth";
import { abandonBattle } from "@/server/adventure";
import { handle, json, HttpError } from "@/server/http";
import { z } from "zod";
import { rateLimit } from "@/server/rateLimit";
export const dynamic = "force-dynamic";
export const POST = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
 const player = await requirePlayer(req);
 await rateLimit(`battles/id/abandon:${player.id}`, 120, 60);
 const { id } = await ctx.params; if (!z.string().uuid().safeParse(id).success) throw new HttpError(400, "invalid_request"); return json(await abandonBattle(player.id, id));
});
