import { timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { telegramUpdates } from "@/db/schema";
import { webhookSecret } from "@/server/env";
import { handle, HttpError, json } from "@/server/http";
import { log } from "@/server/logger";
import { confirmStarsPayment, tgCall, validatePreCheckout, type PreCheckout } from "@/server/payments";

export const dynamic = "force-dynamic";

type Update = {
  update_id: number;
  pre_checkout_query?: PreCheckout;
  message?: {
    chat: { id: number };
    from?: { id: number };
    text?: string;
    successful_payment?: {
      currency: string;
      total_amount: number;
      invoice_payload: string;
      telegram_payment_charge_id: string;
      provider_payment_charge_id?: string;
    };
  };
};

function secretOk(got: string): boolean {
  const a = Buffer.from(got);
  const b = Buffer.from(webhookSecret());
  return a.length === b.length && timingSafeEqual(a, b);
}

export const POST = handle(async (req: Request) => {
  if (!secretOk(req.headers.get("x-telegram-bot-api-secret-token") ?? "")) {
    throw new HttpError(401, "unauthorized");
  }
  const update = (await req.json()) as Update;
  if (!Number.isSafeInteger(update.update_id)) throw new HttpError(400, "invalid_request");

  // Replay protection: an already fully processed update is ignored.
  const [seen] = await db.select().from(telegramUpdates).where(eq(telegramUpdates.updateId, update.update_id));
  if (seen) return json({ ok: true, replay: true });

  if (update.pre_checkout_query) {
    const q = update.pre_checkout_query;
    const err = await validatePreCheckout(q);
    await tgCall("answerPreCheckoutQuery", {
      pre_checkout_query_id: q.id,
      ok: err === null,
      ...(err ? { error_message: err } : {}),
    });
  } else if (update.message?.successful_payment && update.message.from) {
    const sp = update.message.successful_payment;
    const result = await confirmStarsPayment({
      telegramUserId: update.message.from.id,
      payload: sp.invoice_payload,
      totalAmount: sp.total_amount,
      currency: sp.currency,
      chargeId: sp.telegram_payment_charge_id,
      providerChargeId: sp.provider_payment_charge_id,
    });
    log.info("webhook.successful_payment", { result });
  } else if (update.message?.text?.startsWith("/start") && process.env.APP_URL) {
    await tgCall("sendMessage", {
      chat_id: update.message.chat.id,
      text: "Welcome to Velmora! Tap below to play.",
      reply_markup: { inline_keyboard: [[{ text: "Play Velmora", web_app: { url: process.env.APP_URL } }]] },
    });
  }

  // Recorded only AFTER successful processing so Telegram retries on failure.
  await db.insert(telegramUpdates).values({ updateId: update.update_id }).onConflictDoNothing();
  return json({ ok: true });
});
