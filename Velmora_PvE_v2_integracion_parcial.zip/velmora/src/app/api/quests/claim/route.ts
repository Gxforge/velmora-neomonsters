import { requirePlayer } from "@/server/auth";
import { claimQuest } from "@/server/adventure";
import { handle, json, parseBody } from "@/server/http";
import { z } from "zod";
import { rateLimit } from "@/server/rateLimit";
export const dynamic = "force-dynamic";
export const POST = handle(async (req: Request) => {
 const player = await requirePlayer(req);
 await rateLimit(`quests/claim:${player.id}`, 120, 60);
 const { questId } = await parseBody(req, z.object({ questId: z.string().max(60) })); return json(await claimQuest(player.id, questId));
});
