import { z } from "zod";
import { requirePlayer } from "@/server/auth";
import { handle, HttpError, json } from "@/server/http";
import { evolveMonster } from "@/server/monsters";
import { rateLimit } from "@/server/rateLimit";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const player = await requirePlayer(req);
  await rateLimit(`evolve:${player.id}`, 20, 60);
  const id = z.string().uuid().safeParse((await ctx.params).id);
  if (!id.success) throw new HttpError(400, "invalid_request");
  return json(await evolveMonster(player.id, id.data));
});
