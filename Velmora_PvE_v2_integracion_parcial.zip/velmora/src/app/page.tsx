"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { api, ApiError, tgWebApp, useSession } from "@/lib/client/api";
import { playFeedback } from "@/lib/client/feedback";
import { AdventurePanel, Bestiary, type Adventure } from "@/components/AdventurePanel";
import { Collection, type Monster } from "@/components/Collection";
import { Creature } from "@/components/Creature";
import { SKILLS } from "@/lib/game/skills";
import { SPECIES } from "@/lib/game/catalog";
import { elementMultiplier, type Action, type Fighter, type TurnEvent } from "@/lib/game/combat";
import type { Difficulty } from "@/lib/game/adventure";

type Profile = { player: { displayName: string; role: string }; balances: { gold: number; crystals: number };
 monsters: Monster[]; activeBattleId: string | null; needsStarter: boolean };
type Battle = { id: string; status: string; turn: number; player: Fighter; enemy: Fighter; events: TurnEvent[];
 enemyIntent: Action | null; captureAvailable: boolean; captureResult: { success: boolean } | null;
 rewards: { gold: number; crystals: number; xp: number } | null };
type Product = { id: string; name: string; description: string; starsPrice: number };
type Order = { id: string; productId: string; status: string; amount: number };
const tabs = ["Inicio", "Criaturas", "Aventura", "Combate", "Tienda"] as const;
type Tab = typeof tabs[number];
const actionName = { attack: "Ataque", skill: "Habilidad", guard: "Defensa" };
const errors: Record<string,string> = { stale_turn: "El turno cambió. Recupera el combate antes de actuar.",
 legacy_battle_restart_required: "Combate de reglas antiguas: abandónalo y comienza uno nuevo.",
 insufficient_funds: "No tienes suficientes recursos.", level_too_low: "Necesitas más nivel.",
 skill_on_cooldown: "La habilidad está recargando.", region_locked: "Derrota al jefe anterior.",
 region_level_required: "Tu combatiente no alcanza el nivel mínimo.", rate_limited: "Espera un momento antes de reintentar." };
function Health({ f }: { f: Fighter }) {
 return <><div className="flex justify-between"><b>{f.name}</b><span>Nv. {f.level} · {f.element}</span></div>
 <progress max={f.maxHp} value={f.hp} aria-label={`Vida de ${f.name}`}/><p>{f.hp}/{f.maxHp} HP</p>
 {Object.entries(f.effects ?? {}).filter(([,v])=>v>0).map(([k,v])=><span className="badge" key={k}>{k} · {v} rondas</span>)}</>;
}
function stageFor(f: Fighter) { return SPECIES.find(s=>s.name===f.name)?.stage ?? 1; }

export default function Home() {
 const { token, state, relogin } = useSession();
 const [profile, setProfile] = useState<Profile | null>(null);
 const [adventure, setAdventure] = useState<Adventure | null>(null);
 const [battle, setBattle] = useState<Battle | null>(null);
 const [tab, setTab] = useState<Tab>("Inicio");
 const [selected, setSelected] = useState("");
 const [products, setProducts] = useState<Product[]>([]);
 const [orders, setOrders] = useState<Order[]>([]);
 const [msg, setMsg] = useState("");
 const [pending, setPending] = useState(0);
 const [difficulty, setDifficulty] = useState<Difficulty>("normal");
 const [sound, setSound] = useState(false);
 const [vibration, setVibration] = useState(false);
 const [reduced, setReduced] = useState(false);
 const [log, setLog] = useState<string[]>([]);
 const [flash, setFlash] = useState("");
 const acting = useRef(false);
 // A lost response is retried with the SAME id and expected turn.
 const actionRequest = useRef<{ action: Action; actionId: string; expectedTurn: number } | null>(null);
 const busy = pending > 0;
 const run = useCallback(async <T,>(fn: (tk: string) => Promise<T>): Promise<T | null> => {
  if (!token) return null;
  setPending(n=>n+1);
  try { return await fn(token); }
  catch(e) {
   if(e instanceof ApiError && e.status === 401) void relogin();
   setMsg(e instanceof ApiError ? errors[e.code] ?? `Error: ${e.code}` : "Conexión interrumpida. Puedes reintentar.");
   return null;
  } finally { setPending(n=>Math.max(0,n-1)); }
 }, [token,relogin]);
 const refresh = useCallback(async () => {
  const data = await run(async tk => Promise.all([
   api<Profile>("/api/me",{token:tk}), api<Adventure>("/api/adventure",{token:tk}),
  ]));
  if(data) { setProfile(data[0]);setAdventure(data[1]);return data[0]; }
  return null;
 },[run]);
 const refreshOrders = useCallback(async () => {
  const data = await run(tk=>api<{orders:Order[]}>("/api/payments/history",{token:tk}));
  if(data) { setOrders(data.orders); return data.orders; }
  return [];
 },[run]);
 useEffect(()=>{
  if(!token) return;
  const timer = setTimeout(()=>{
   void refresh().then(async p=>{
    if(p?.activeBattleId) {
     const b = await run(tk=>api<Battle>(`/api/battles/${p.activeBattleId}`,{token:tk}));
     if(b) { setBattle(b);setTab("Combate"); }
    }
   });
   void run(tk=>api<{products:Product[]}>("/api/shop/products",{token:tk})).then(r=>r&&setProducts(r.products));
   void refreshOrders();
  },0);
  return ()=>clearTimeout(timer);
 },[token,refresh,run,refreshOrders]);
 const current = profile?.monsters.find(m=>m.id===selected) ?? profile?.monsters[0];
 async function start(regionId?: string,boss=false) {
  if(!current) return;
  const b=await run(tk=>api<Battle>("/api/battles",{token:tk,body:{monsterId:current.id,regionId,boss,difficulty}}));
  if(b) { actionRequest.current=null;setBattle(b);setLog([]);setTab("Combate"); }
 }
 async function act(action: Action) {
  if(!battle || acting.current) return;
  const request=actionRequest.current ?? {action,actionId:crypto.randomUUID(),expectedTurn:battle.turn};
  if(request.action!==action) {setMsg("Reintenta primero la acción pendiente o recupera el estado.");return;}
  actionRequest.current=request;acting.current=true;
  setPending(n=>n+1);
  try {
   const b=await run(tk=>api<Battle>(`/api/battles/${battle.id}/action`,{token:tk,body:request}));
   if(!b) return;
   actionRequest.current=null;
   const visual=structuredClone(battle);
   for(const ev of b.events) {
    const target=ev.actor==="player"?"enemy":"player";
    visual[target].hp=ev.targetHp;
    if(ev.actorHp!==undefined) visual[ev.actor].hp=ev.actorHp;
    const text=`${ev.actor==="player"?"Tu criatura":"Rival"}: ${actionName[ev.action]} · ${ev.damage} daño${ev.crit?" · crítico":""}${ev.effect?` · ${ev.effect}`:""} · ${ev.effectiveness}`;
    setLog(prev=>[...prev.slice(-79),text]);setFlash(target);
    setBattle(structuredClone(visual));
    if(ev.damage>0) playFeedback("hit",sound,vibration);
    if(!reduced && !window.matchMedia("(prefers-reduced-motion: reduce)").matches)
     await new Promise(resolve=>setTimeout(resolve,450));
   }
   setFlash("");setBattle(b);
   if(b.status!=="active") {playFeedback("victory",sound&&b.status==="won",vibration);await refresh();}
  } finally {acting.current=false;setPending(n=>Math.max(0,n-1));}
 }
 async function recover() {
  if(!battle) return;
  const b=await run(tk=>api<Battle>(`/api/battles/${battle.id}`,{token:tk}));
  if(b) {setBattle(b);actionRequest.current=null;
   setLog(b.events.map(ev=>`${ev.actor === "player" ? "Tu criatura" : "Rival"}: ${actionName[ev.action]} · ${ev.damage} daño${ev.effect ? ` · ${ev.effect}` : ""}`));
   setMsg("Estado recuperado.");await refresh();}
 }
 if(state==="loading") return <Shell><p role="status">Conectando…</p></Shell>;
 if(state==="no-telegram") return <Shell><h1>Velmora</h1><p>Abre esta Mini App desde el bot de Telegram.</p></Shell>;
 if(state==="banned") return <Shell><p>Esta cuenta está suspendida.</p></Shell>;
 if(!profile) return <Shell><p role="status">{msg || (state==="error" ? "No se pudo iniciar sesión." : "Cargando…")}</p>
 <button onClick={()=>state==="error"?void relogin():void refresh()}>Reintentar</button></Shell>;
 return <Shell reduced={reduced}>
 <header className="flex justify-between items-center"><div><h1>Velmora</h1><p>{profile.player.displayName}</p></div>
 <div><p>Oro: {profile.balances.gold}</p><p>Cristales: {profile.balances.crystals}</p></div></header>
 {profile.player.role==="admin"&&<Link href="/admin">Administración</Link>}
 <p role="status" aria-live="polite">{msg}</p>
 <nav className="nav" aria-label="Secciones">{tabs.map(t=><button key={t} aria-current={tab===t?"page":undefined} onClick={()=>setTab(t)}>{t}</button>)}</nav>
 {busy&&<p role="status">Procesando…</p>}
 {profile.needsStarter ? <section><h2>Tu aventura comienza aquí</h2><p>Elige un inicial, gana un combate y realiza tu primera captura garantizada.</p>
 <div className="grid grid-cols-3 gap-2">{["fire","water","earth"].map(line=><button key={line} disabled={busy} onClick={async()=>{
  const r=await run(tk=>api("/api/starter",{token:tk,body:{lineId:line}}));if(r){await refresh();setTab("Aventura");}
 }}><Creature element={line} name={line} size={64}/>{line}</button>)}</div></section> :
 tab==="Inicio" ? <section className="space-y-4">
 {current&&<article className="card"><Creature element={current.element} stage={current.stage} name={current.name}/><h2>{current.name} · Nv. {current.level}</h2>
 <button onClick={()=>setTab("Aventura")}>Continuar aventura</button></article>}
 {adventure&&<><article className="card"><h2>Primeros pasos</h2><ol><li>{adventure.tutorial.starter?"✓":"○"} Elige un inicial</li>
 <li>{adventure.tutorial.battle?"✓":"○"} Gana un combate</li><li>{adventure.tutorial.capture?"✓":"○"} Captura otra criatura</li></ol>
 <p>Cada victoria entrega cristales. Ninguna evolución exige comprar.</p></article><Bestiary data={adventure}/>
 <details className="card"><summary>Historial de combates</summary>{adventure.history.map(b=><p key={b.id}>{b.regionId??"Entrenamiento"} · {b.status} · {b.turn} rondas</p>)}</details></>}
 <details className="card"><summary>Ajustes</summary>
 <label><input type="checkbox" checked={sound} onChange={e=>setSound(e.target.checked)}/> Sonido</label>
 <label><input type="checkbox" checked={vibration} onChange={e=>setVibration(e.target.checked)}/> Vibración</label>
 <label><input type="checkbox" checked={reduced} onChange={e=>setReduced(e.target.checked)}/> Movimiento reducido</label></details>
 </section> : tab==="Criaturas" ? <Collection monsters={profile.monsters} selected={current?.id??""} choose={setSelected} busy={busy} balances={profile.balances}
 evolve={async id=>{const r=await run(tk=>api(`/api/monsters/${id}/evolve`,{token:tk,body:{}}));if(r){playFeedback("evolve",sound,vibration);await refresh();}}}/> :
 tab==="Aventura" ? adventure&&<AdventurePanel data={adventure} level={current?.level??1} busy={busy} difficulty={difficulty} setDifficulty={setDifficulty}
 start={(id,boss)=>void start(id,boss)} claim={async id=>{const r=await run(tk=>api("/api/quests/claim",{token:tk,body:{questId:id}}));if(r)await refresh();}}/> :
 tab==="Combate" ? <section className="space-y-3"><h2>Combate PvE</h2>
 <p>El PvP no está disponible en esta versión; no se simulan rivales humanos.</p>
 {!battle||battle.status!=="active" ? <>
 {battle&&<article className="card"><h3>{battle.status==="won"?"Victoria":battle.status==="draw"?"Empate":battle.status==="abandoned"?"Abandono":"Derrota"}</h3>
 {battle.rewards&&<p>+{battle.rewards.gold} oro · +{battle.rewards.xp} XP · +1 cristal. Los bonos de jefe se suman al saldo.</p>}
 {battle.captureAvailable&&<button disabled={busy} onClick={async()=>{
  const r=await run(tk=>api<{success:boolean}>(`/api/battles/${battle.id}/capture`,{token:tk,body:{}}));
  if(r){setMsg(r.success?"¡Criatura capturada!":"La criatura escapó.");await recover();}
 }}>Capturar · {profile.monsters.length<=1?100:65}% · un intento sin coste</button>}
 {battle.captureResult&&<p>{battle.captureResult.success?"Capturada":"Escapó"}</p>}</article>}
 <p>Combatiente: {current?.name}. Puedes cambiarlo en Criaturas.</p><button disabled={busy} onClick={()=>void start()}>Entrenamiento</button><button onClick={()=>setTab("Aventura")}>Explorar regiones</button>
 </> : <>
 <div className="arena"><article className={`fighter enemy ${flash==="enemy"?"hit":""}`}><Creature element={battle.enemy.element} stage={stageFor(battle.enemy)} name={battle.enemy.name} size={128}/><Health f={battle.enemy}/></article>
 <article className={`fighter player ${flash==="player"?"hit":""}`}><Creature element={battle.player.element} stage={stageFor(battle.player)} name={battle.player.name} size={128}/><Health f={battle.player}/></article></div>
 <p>Ronda {battle.turn}/40 · Intención rival: {battle.enemyIntent?actionName[battle.enemyIntent]:"—"}</p>
 <p>Afinidad de tu ataque: ×{elementMultiplier(battle.player.element,battle.enemy.element)} · Primero actúa: {battle.player.spd*((battle.player.effects?.haste??0)>0?1.3:1)>=battle.enemy.spd*((battle.enemy.effects?.haste??0)>0?1.3:1)?"tu criatura":"rival"}</p>
 <p>{SKILLS[battle.player.element].name}: {SKILLS[battle.player.element].effect}</p>
 <div className="grid grid-cols-3 gap-2">{(["attack","skill","guard"] as const).map(a=><button key={a} disabled={busy||(a==="skill"&&battle.player.skillCooldown>0)} onClick={()=>void act(a)}>{actionName[a]}{a==="skill"&&battle.player.skillCooldown>0?` (${battle.player.skillCooldown})`:""}</button>)}</div>
 <p>Defensa: prioridad inmediata y −50% de daño durante esta ronda. Tras 40 rondas sin ganador, empate.</p>
 <button disabled={busy} onClick={()=>void recover()}>Recuperar estado</button>
 <button disabled={busy} onClick={async()=>{if(!confirm("¿Abandonar sin recompensas?"))return; const r=await run(tk=>api(`/api/battles/${battle.id}/abandon`,{token:tk,body:{}}));if(r)await recover();}}>Abandonar</button>
 </>}
 <details className="card" open><summary>Registro de combate</summary><ul aria-live="polite">{log.map((text,i)=><li key={i}>{text}</li>)}</ul></details>
 </section> : <section className="space-y-3"><h2>Tienda</h2><p>Compras con Telegram Stars. La confirmación del servidor es la que entrega los recursos. La progresión también se completa jugando.</p>
 {products.map(p=><article className="card" key={p.id}><h3>{p.name}</h3><p>{p.description} · {p.starsPrice} Stars</p>
 <button disabled={busy} onClick={async()=>{
 const invoice=await run(tk=>api<{orderId:string;invoiceLink:string}>("/api/payments/stars/invoice",{token:tk,body:{productId:p.id}}));
 if(!invoice)return;
 const tg=tgWebApp();if(!tg?.openInvoice){setMsg("Telegram no permite abrir la factura aquí.");return;}
 tg.openInvoice(invoice.invoiceLink,status=>{
 setMsg(`Factura: ${status}. Verifica la confirmación en el historial.`);
 void (async()=>{
  for(let i=0;i<12;i++) {
   await new Promise(resolve=>setTimeout(resolve,2000));
   const list=await refreshOrders();const order=list.find(o=>o.id===invoice.orderId);
   if(order&&order.status!=="pending") {setMsg(`Compra: ${order.status}`);await refresh();break;}
  }
 })();
 });
 }}>Comprar</button></article>)}
 <h3>Historial de compras</h3><button disabled={busy} onClick={()=>void refreshOrders()}>Actualizar estado</button>
 {orders.map(o=><p key={o.id}>{o.productId} · {o.amount} Stars · {o.status}</p>)}
 </section>}
 </Shell>;
}
function Shell({children,reduced=false}:{children:React.ReactNode;reduced?:boolean}) {
 return <main className={`shell ${reduced?"reduced":""}`}>{children}</main>;
}
