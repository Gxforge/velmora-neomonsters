"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { api, ApiError, useSession } from "@/lib/client/api";

type Player = { id: string; displayName: string; role: string; status: string; username: string | null; telegramUserId: number | null };
type Metrics = Record<string, number | null>;
type Log = { id: string; action: string; targetType: string | null; targetId: string | null; createdAt: string };

/**
 * UI only. Every call below is authorized by the BACKEND (requireAdmin):
 * hiding this page protects nothing, the API rejects non-admins with 403.
 */
export default function AdminPage() {
  const { token, state } = useSession();
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");

  const load = useCallback(async (t: string, query: string) => {
    try {
      const [m, p, l] = await Promise.all([
        api<Metrics>("/api/admin/metrics", { token: t }),
        api<{ players: Player[] }>(`/api/admin/players?q=${encodeURIComponent(query)}`, { token: t }),
        api<{ logs: Log[] }>("/api/admin/audit", { token: t }),
      ]);
      setMetrics(m); setPlayers(p.players); setLogs(l.logs); setErr("");
    } catch (e) {
      setErr(e instanceof ApiError && e.status === 403 ? "Forbidden" : "Error loading admin data");
    }
  }, []);

  useEffect(() => {
    if (!token) return;
    const t = setTimeout(() => void load(token, ""), 0);
    return () => clearTimeout(t);
  }, [token, load]);

  const ban = async (p: Player) => {
    if (!token) return;
    const banned = p.status !== "banned";
    const reason = window.prompt(banned ? "Ban reason" : "Unban reason");
    if (!reason || reason.length < 3) return;
    try {
      await api(`/api/admin/players/${p.id}/ban`, { token, body: { banned, reason } });
      await load(token, q);
    } catch (e) {
      setErr(e instanceof ApiError ? e.code : "error");
    }
  };

  if (state !== "ready") return <main className="p-4">{state === "loading" ? "Connecting…" : "Open from Telegram."}</main>;
  if (err === "Forbidden") return <main className="p-4">403 — not an administrator. <Link className="underline" href="/">Back</Link></main>;

  return (
    <main className="mx-auto max-w-3xl space-y-6 p-4 text-sm">
      <div className="flex justify-between"><h1 className="text-lg font-semibold">Admin</h1><Link className="underline" href="/">Game</Link></div>
      {err && <p className="text-red-300">{err}</p>}
      {metrics && (
        <section className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {Object.entries(metrics).map(([k, v]) => (
            <div key={k} className="rounded bg-white/5 p-2"><p className="text-xs text-white/50">{k}</p><p className="text-lg">{v ?? "—"}</p></div>
          ))}
        </section>
      )}
      <section>
        <form className="mb-2 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (token) void load(token, q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name/username" className="flex-1 rounded bg-white/10 p-2" />
          <button className="rounded bg-violet-600 px-3">Search</button>
        </form>
        <ul className="space-y-1">
          {players.map((p) => (
            <li key={p.id} className="flex items-center justify-between rounded bg-white/5 p-2">
              <span>{p.displayName} <span className="text-white/50">@{p.username ?? "—"} · {p.role} · {p.status}</span></span>
              {p.role !== "admin" && <button onClick={() => ban(p)} className="rounded bg-red-700 px-2 py-1 text-xs">{p.status === "banned" ? "Unban" : "Ban"}</button>}
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h2 className="mb-1 font-semibold">Audit log</h2>
        <ul className="space-y-1 text-xs text-white/70">
          {logs.map((l) => <li key={l.id}>{new Date(l.createdAt).toISOString()} · {l.action} {l.targetType ?? ""} {l.targetId ?? ""}</li>)}
        </ul>
      </section>
    </main>
  );
}
