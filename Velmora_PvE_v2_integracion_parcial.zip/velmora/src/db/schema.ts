/**
 * Velmora database schema (single source of truth).
 *
 * SQL migrations in /supabase/migrations are generated from this file with
 * `npm run db:generate`, plus hand-written hardening migrations (RLS,
 * append-only triggers). Never edit a database by hand without a migration.
 *
 * Security model: the browser NEVER talks to the database. All tables have
 * RLS enabled with no policies for `anon` / `authenticated`; only the backend
 * (privileged connection) reads/writes. Telegram identity is separated from
 * the game account (players).
 */
import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  check,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
  unique,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

const ts = (name: string) => timestamp(name, { withTimezone: true });

// ---------------------------------------------------------------- accounts
export const players = pgTable(
  "players",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    displayName: text("display_name").notNull(),
    role: text("role").notNull().default("player"),
    status: text("status").notNull().default("active"),
    bannedReason: text("banned_reason"),
    bannedAt: ts("banned_at"),
    createdAt: ts("created_at").notNull().defaultNow(),
    lastSeenAt: ts("last_seen_at").notNull().defaultNow(),
  },
  (t) => [
    check("players_role_chk", sql`${t.role} in ('player','admin')`),
    check("players_status_chk", sql`${t.status} in ('active','banned')`),
  ],
);

/** Telegram identity, decoupled from the game account. */
export const telegramIdentities = pgTable("telegram_identities", {
  telegramUserId: bigint("telegram_user_id", { mode: "number" }).primaryKey(),
  playerId: uuid("player_id")
    .notNull()
    .unique()
    .references(() => players.id, { onDelete: "cascade" }),
  username: text("username"),
  firstName: text("first_name"),
  languageCode: text("language_code"),
  createdAt: ts("created_at").notNull().defaultNow(),
  lastAuthAt: ts("last_auth_at").notNull().defaultNow(),
});

// ----------------------------------------------------------------- economy
export const playerBalances = pgTable(
  "player_balances",
  {
    playerId: uuid("player_id")
      .primaryKey()
      .references(() => players.id, { onDelete: "cascade" }),
    gold: bigint("gold", { mode: "number" }).notNull().default(0),
    crystals: bigint("crystals", { mode: "number" }).notNull().default(0),
    updatedAt: ts("updated_at").notNull().defaultNow(),
  },
  (t) => [
    check("balances_gold_nonneg", sql`${t.gold} >= 0`),
    check("balances_crystals_nonneg", sql`${t.crystals} >= 0`),
  ],
);

/** Append-only audit trail for every balance change. */
export const ledgerEntries = pgTable(
  "ledger_entries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    playerId: uuid("player_id")
      .notNull()
      .references(() => players.id, { onDelete: "restrict" }),
    currency: text("currency").notNull(),
    delta: bigint("delta", { mode: "number" }).notNull(),
    balanceAfter: bigint("balance_after", { mode: "number" }).notNull(),
    reason: text("reason").notNull(),
    refType: text("ref_type"),
    refId: text("ref_id"),
    idempotencyKey: text("idempotency_key").notNull().unique(),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [
    check("ledger_currency_chk", sql`${t.currency} in ('gold','crystals')`),
    check("ledger_delta_nonzero", sql`${t.delta} <> 0`),
    index("ledger_player_idx").on(t.playerId, t.createdAt),
  ],
);

export const inventoryItems = pgTable(
  "inventory_items",
  {
    playerId: uuid("player_id")
      .notNull()
      .references(() => players.id, { onDelete: "cascade" }),
    itemId: text("item_id").notNull(),
    quantity: integer("quantity").notNull().default(0),
  },
  (t) => [
    primaryKey({ columns: [t.playerId, t.itemId] }),
    check("inventory_qty_nonneg", sql`${t.quantity} >= 0`),
  ],
);

// ---------------------------------------------------------------- monsters
export const monsterSpecies = pgTable(
  "monster_species",
  {
    id: text("id").primaryKey(),
    lineId: text("line_id").notNull(),
    name: text("name").notNull(),
    element: text("element").notNull(),
    stage: integer("stage").notNull(),
    evolvesTo: text("evolves_to"),
    baseHp: integer("base_hp").notNull(),
    baseAtk: integer("base_atk").notNull(),
    baseDef: integer("base_def").notNull(),
    baseSpd: integer("base_spd").notNull(),
  },
  (t) => [
    check("species_stage_chk", sql`${t.stage} between 1 and 3`),
    check(
      "species_element_chk",
      sql`${t.element} in ('fire','water','earth','lightning','light','dark')`,
    ),
  ],
);

export const playerMonsters = pgTable(
  "player_monsters",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    playerId: uuid("player_id")
      .notNull()
      .references(() => players.id, { onDelete: "cascade" }),
    speciesId: text("species_id")
      .notNull()
      .references(() => monsterSpecies.id),
    level: integer("level").notNull().default(1),
    xp: integer("xp").notNull().default(0),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [
    check("monster_level_chk", sql`${t.level} between 1 and 100`),
    check("monster_xp_chk", sql`${t.xp} >= 0`),
    index("player_monsters_player_idx").on(t.playerId),
  ],
);

// ------------------------------------------------------------------ combat
/** Server-authoritative PvE battles. Real PvP is NOT IMPLEMENTED yet. */
export const battles = pgTable(
  "battles",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    mode: text("mode").notNull().default("pve"),
    status: text("status").notNull().default("active"),
    playerId: uuid("player_id")
      .notNull()
      .references(() => players.id),
    playerMonsterId: uuid("player_monster_id")
      .notNull()
      .references(() => playerMonsters.id),
    enemySpeciesId: text("enemy_species_id")
      .notNull()
      .references(() => monsterSpecies.id),
    enemyLevel: integer("enemy_level").notNull(),
    seed: text("seed").notNull(),
    state: jsonb("state").notNull(),
    turnNo: integer("turn_no").notNull().default(0),
    rewardGold: integer("reward_gold").notNull().default(0),
    rewardXp: integer("reward_xp").notNull().default(0),
    regionId: text("region_id"),
    boss: boolean("boss").notNull().default(false),
    difficulty: text("difficulty").notNull().default("normal"),
    rulesVersion: text("rules_version").notNull().default("legacy-v1"),
    captureResult: jsonb("capture_result"),
    createdAt: ts("created_at").notNull().defaultNow(),
    finishedAt: ts("finished_at"),
  },
  (t) => [
    check("battles_mode_chk", sql`${t.mode} in ('pve')`),
    check("battles_status_chk", sql`${t.status} in ('active','won','lost','draw','abandoned')`),
    index("battles_player_idx").on(t.playerId, t.createdAt),
    uniqueIndex("battles_one_active_player").on(t.playerId).where(sql`${t.status} = 'active'`),
  ],
);

export const battleTurns = pgTable(
  "battle_turns",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    battleId: uuid("battle_id")
      .notNull()
      .references(() => battles.id, { onDelete: "cascade" }),
    turnNo: integer("turn_no").notNull(),
    actor: text("actor").notNull(),
    action: text("action").notNull(),
    result: jsonb("result").notNull(),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [
    unique("battle_turns_unique").on(t.battleId, t.turnNo, t.actor),
    check("battle_turns_actor_chk", sql`${t.actor} in ('player','enemy')`),
  ],
);

// ---------------------------------------------------------------- payments
export const products = pgTable(
  "products",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    description: text("description").notNull(),
    starsPrice: integer("stars_price").notNull(),
    grants: jsonb("grants").notNull(),
    active: boolean("active").notNull().default(true),
  },
  (t) => [check("products_price_chk", sql`${t.starsPrice} > 0`)],
);

/** One row per invoice. Goods are only delivered after a confirmed payment. */
export const paymentOrders = pgTable(
  "payment_orders",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    playerId: uuid("player_id")
      .notNull()
      .references(() => players.id),
    telegramUserId: bigint("telegram_user_id", { mode: "number" }).notNull(),
    productId: text("product_id")
      .notNull()
      .references(() => products.id),
    payload: text("payload").notNull().unique(),
    amount: integer("amount").notNull(),
    productSnapshot: jsonb("product_snapshot").notNull(),
    currency: text("currency").notNull().default("XTR"),
    status: text("status").notNull().default("pending"),
    telegramPaymentChargeId: text("telegram_payment_charge_id").unique(),
    providerPaymentChargeId: text("provider_payment_charge_id"),
    createdAt: ts("created_at").notNull().defaultNow(),
    confirmedAt: ts("confirmed_at"),
  },
  (t) => [
    check(
      "payment_status_chk",
      sql`${t.status} in ('pending','confirmed','failed','cancelled','refunded')`,
    ),
    check("payment_currency_chk", sql`${t.currency} = 'XTR'`),
    index("payment_orders_player_idx").on(t.playerId),
  ],
);

// ----------------------------------------------------- security/observability
export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorPlayerId: uuid("actor_player_id"),
    action: text("action").notNull(),
    targetType: text("target_type"),
    targetId: text("target_id"),
    metadata: jsonb("metadata").notNull().default({}),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [index("audit_logs_created_idx").on(t.createdAt)],
);

export const rateLimits = pgTable(
  "rate_limits",
  {
    key: text("key").notNull(),
    windowStart: ts("window_start").notNull(),
    count: integer("count").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.key, t.windowStart] })],
);

/** Telegram update_id dedupe: webhook replays are ignored. */
export const telegramUpdates = pgTable("telegram_updates", {
  updateId: bigint("update_id", { mode: "number" }).primaryKey(),
  receivedAt: ts("received_at").notNull().defaultNow(),
});

/** Stored responses make network retries safe, including a finished turn. */
export const battleActions = pgTable("battle_actions", {
  battleId: uuid("battle_id").notNull().references(() => battles.id, { onDelete: "cascade" }),
  actionId: uuid("action_id").notNull(),
  expectedTurn: integer("expected_turn").notNull(),
  action: text("action").notNull(),
  response: jsonb("response").notNull(),
}, t => [primaryKey({ columns: [t.battleId, t.actionId] })]);
export const progressionClaims = pgTable("progression_claims", {
  playerId: uuid("player_id").notNull().references(() => players.id),
  claimId: text("claim_id").notNull(),
  createdAt: ts("created_at").notNull().defaultNow(),
}, t => [primaryKey({ columns: [t.playerId, t.claimId] })]);
