import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

const isLocal = /@(127\.0\.0\.1|localhost)[:/]/.test(databaseUrl);

const globalForDb = globalThis as typeof globalThis & {
  __velmoraPool?: Pool;
};

export const pool =
  globalForDb.__velmoraPool ??
  new Pool({
    connectionString: databaseUrl,
    // Supabase requires TLS; local Postgres does not.
    ssl: isLocal ? false : { rejectUnauthorized: false },
    // Serverless-friendly: keep the pool small.
    max: isLocal ? 10 : 3,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__velmoraPool = pool;
}

export const db = drizzle(pool, { schema });
export type Db = typeof db;
export type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];
export { schema };
