# Database

Source of truth: `src/db/schema.ts` (Drizzle). SQL migrations live in `supabase/migrations/` and are generated with `npm run db:generate`, plus hand-written hardening migrations. Apply with `npm run db:migrate` (tracks files in `public._velmora_migrations`).

| Migration | Content |
|---|---|
| `20261002050117_initial_schema.sql` | all tables, constraints, indexes (generated) |
| `20261002050200_security_hardening.sql` | RLS on all tables, API-role revokes, append-only triggers, payment status guard |

## Environments (separate Supabase projects)
| Env | Project | Status |
|---|---|---|
| staging/development | `velmora-staging` | IMPLEMENTED, migrations applied |
| production | `velmora-game-prod` | IMPLEMENTED, legacy test tables dropped, migrations applied |

A legacy third project (`velmora-admin-analytics`) was removed: admin/analytics lives in the same database behind backend authorization. A backup of the few legacy test rows was kept outside the repository.

## Tables
`players`, `telegram_identities`, `player_balances`, `ledger_entries` (append-only), `inventory_items`, `monster_species`, `player_monsters`, `battles`, `battle_turns` (append-only), `products`, `payment_orders`, `audit_logs` (append-only), `rate_limits`, `telegram_updates`.

## Integrity
CHECK constraints (non-negative balances, stage/level ranges, status enums), unique idempotency keys, unique payment payload and charge id, triggers that forbid UPDATE/DELETE on ledger/audit/turn tables and illegal payment status transitions.

## RLS model — PARTIAL (deny-by-default)
Authentication is Telegram-based, not Supabase Auth, so there is no `auth.uid()` to write per-row policies against. All tables have RLS **enabled with zero policies** and privileges revoked from `anon`/`authenticated`: the Supabase REST/GraphQL APIs cannot read or write anything. Only the backend's privileged connection can. If Supabase Auth or JWT-minting is added later, per-user SELECT policies must be added with tests. An integration test asserts RLS is enabled on every table.

## Not done
- Supabase Storage buckets/policies: NOT IMPLEMENTED.
- TON tables (`blockchain_transactions`, deposits, withdrawals): NOT IMPLEMENTED on purpose.
- PvP tables: NOT IMPLEMENTED.
