# Deployment

## Branch model
| Branch | Purpose | Target |
|---|---|---|
| `main` | production | Vercel Production + `velmora-game-prod` Supabase |
| `develop` | staging | Vercel Preview + `velmora-staging` Supabase |

GitHub repository: `Gxforge/velmora` (private) — IMPLEMENTED, `main` and `develop` pushed.

## CI — IMPLEMENTED
`.github/workflows/ci.yml` on push/PR to `main` and `develop`: forbidden-name + secret scan, lint, typecheck, migrations against a throwaway Postgres, unit+integration tests, palette audit, build.

## Vercel — NOT IMPLEMENTED (blocked)
The Vercel token provided was rejected by the Vercel API (`invalidToken`), so no project, Git integration or environment variables could be created. To finish:
1. Provide a valid Vercel token (or import the repo from the Vercel dashboard with the GitHub integration).
2. Import `Gxforge/velmora`, framework Next.js, production branch `main`. Vercel will then deploy every push to `main` to production and every other branch (`develop`) to a Preview URL automatically, without any token in CI.
3. Environment variables (see `.env.example`): *Production* scope = production Supabase values; *Preview* scope = staging Supabase values. Generate `SESSION_SECRET` and `TELEGRAM_WEBHOOK_SECRET` separately for each (`openssl rand -hex 32`). Use the Supabase **pooler** connection string for `DATABASE_URL`.
4. Protect `main` in GitHub so CI must pass before merge (TODO: branch protection not configured).
5. Register the Telegram webhook (TELEGRAM.md).

## Database migrations
Applied manually per environment with `DATABASE_URL=<env url> npm run db:migrate`. Automating migrations on deploy is TODO. Never edit a database without a migration.

## Environments
Local development must use staging (or a local Postgres), never production credentials.
